# MTB Pinball 3D Arcade — prototype 0.1

Un plateau **VPX réel** de test, une seule bille, deux batteurs, deux guides et un rendu 3D Three.js. Les collisions, la gravité, le roulement et les forces des batteurs sont calculés par **VPX-JS 1.3.4**, le port du code physique Visual Pinball **10.6**. Les fichiers physiques upstream sont inchangés et vérifiés par SHA-256. Il s'agit du port JavaScript, avec les limites de cette version ; la fidélité au VPX natif actuel n'a pas été mesurée.

**État vérifié :** les deux dépôts compilent après adaptation de leur chaîne de compilation. Les tests de physique, commandes et worker passent. **Le rendu dans Safari Mac/iPhone reste à vérifier sur vos appareils.** Les navigateurs graphiques n'ont pas pu démarrer dans l'environnement de réalisation. Le dossier `dist/` est déjà compilé et contient tous les fichiers nécessaires au jeu.

## Tester sur Mac Apple Silicon et iPhone

1. Décompressez l'archive. Ouvrez Terminal dans le dossier `mtb-pinball-3d-arcade`.
2. Lancez `bash Start.command`. Le script utilise Node.js s'il est installé, sinon Python 3. Il affiche les adresses du Mac et de l'iPhone. Vous pouvez aussi lancer directement `node scripts/serve.mjs` avec Node.js 24 arm64.
3. Ouvrez **http://localhost:8080** dans Safari sur le Mac, puis cliquez **Lancer**. Commandes : **A / D**, les touches Maj gauche / droite, ou les flèches gauche / droite ; **Espace** lance une bille ; **P** met en pause.
4. Connectez l'iPhone au **même Wi-Fi** que le Mac. Ouvrez dans Safari l'adresse affichée, par exemple **http://192.168.1.42:8080**. Touchez **Lancer**, puis maintenez les deux boutons **Gauche / Droite** avec deux doigts. Relâchez un doigt : l'autre batteur doit rester levé.
5. Ouvrez **Diagnostic**, puis **Lancer les tests**. Les résultats sont produits sur votre appareil. **Exporter JSON** permet de conserver le diagnostic. Revenez au jeu pour contrôler le rendu, les collisions visibles et la fluidité.
6. Dans Terminal, **Ctrl+C** arrête le serveur.

La version précompilée ne nécessite **ni npm install, ni Xcode, ni Rosetta** lorsque Node ou Python est déjà disponible. Ne l'ouvrez pas par `file://` : le chargement du VPX et du worker nécessite le serveur HTTP. Le test Wi-Fi fonctionne sans service worker, compte ou hébergement externe ; le Mac doit rester allumé et le serveur actif.

Si l'iPhone ne charge pas la page, vérifiez l'adresse Wi-Fi du Mac (Réglages système → Wi-Fi → Détails → TCP/IP), le port 8080, le même réseau et l'autorisation du serveur dans le pare-feu macOS. Un réseau invité peut isoler les appareils. Pour un port déjà utilisé : `PORT=8081 node scripts/serve.mjs`, puis utilisez 8081 dans les deux adresses.

## Contrôle manuel indispensable dans Safari

| Action | Résultat attendu |
|---|---|
| Lancer | Une bille métallique visible monte, rebondit et redescend |
| Maintenir Gauche et Droite | Les deux batteurs montent simultanément |
| Relâcher un seul doigt | Seul le batteur correspondant redescend |
| Glisser hors d'un bouton puis relâcher | Le batteur revient ; la capture du pointeur conserve le relâchement |
| Ajouter un deuxième doigt sur le même bouton | Relâcher un doigt conserve le batteur tenu par l'autre |
| Toucher un batteur au passage de la bille | La bille reçoit une impulsion réelle du moteur VPX-JS |
| Toucher un guide / un bord | Déviation et rebond réels ; les lignes peintes sur le plateau sont décoratives |
| Changer d'application / verrouiller l'iPhone | Les commandes se libèrent et le jeu passe en pause |
| Reprendre | Pas de rattrapage brutal de toute la durée de suspension |
| Tourner l'iPhone | Plateau et boutons restent accessibles |
| Jouer plusieurs minutes | Noter FPS, modèle d'iPhone, version iOS, latence ressentie et chauffe |

La bille est retirée lorsqu'elle atteint la zone de sortie au-dessous des batteurs. **Nouvelle bille** la recrée ; il n'y a jamais plusieurs billes simultanément.

## Recompiler et tester

Avec Node.js **24** et npm, dans ce dossier :

```bash
npm ci
npm run build
npm test
npm run verify:upstream
npm start
```

`npm run build` régénère le conteneur OLE/BIFF `public/mtb-test.vpx`, puis compile le jeu, le worker et la page de diagnostic. Aucun téléchargement de table ou de ROM n'est nécessaire. Le VPX est effectivement chargé par `Table.load` ; ce n'est pas un JSON déguisé. Sa lecture est validée par VPX-JS ; son ouverture et sa jouabilité autonome dans l'éditeur/binaire natif VPX ne sont pas certifiées.

`npm test` exécute dix scénarios de physique/entrée, sept contrôles du **bundle navigateur réel** dans une VM Node et les contrôles du serveur HTTP. **Une VM Node ne valide pas WebGL ou Safari.** Les rapports sont dans `reports/`.

Tests graphiques optionnels sur le Mac :

```bash
npx playwright install chromium webkit
npm run test:browser
```

Ces tests chargent le jeu, vérifient le worker, le mouvement de bille, les deux batteurs, la libération indépendante, `pointercancel`, la pause et les deux orientations. Les pointeurs simulés ne certifient pas la réception physique de deux doigts sur iOS. WebKit de Playwright n'est pas Safari sur iPhone.

Tests upstream supplémentaires : `npm run test:upstream`. Résultat de réalisation : **30 réussites / 32 tests** ; les deux échecs appellent l'export GLTF de l'adaptateur navigateur, qui renvoie `not implemented` upstream. Cette commande retourne donc un échec pour rendre ces limites visibles. Les tests de collisions/batteurs/bille de cet ensemble passent. Ce n'est pas la suite upstream entière.

## Dépôts récupérés et compilations

| Projet | Origine | Commit testé |
|---|---|---|
| VPX-JS 1.3.4 | https://github.com/vpdb/vpx-js | `e8a6d6fa52262a757d38b2317d845043e5fe1c95` |
| VPWeb 1.0.0 | https://github.com/freezy/vpweb | `c0b28d383577fa979509d966198d100f2647f5c8` |

Les deux commits datent de 2020. Les versions et hashes sont figés dans `sources.lock.json`, avec les empreintes de 568 fichiers upstream conservés.

- L'installation d'origine échoue sur les vieux modules natifs `sharp` / `node-gyp` (la chaîne tente notamment une syntaxe Python 2 sur Python 3). Les builds lancés après cette installation incomplète échouent également.
- **VPX-JS :** `npm ci --ignore-scripts`, puis `npm run build` réussit : ESM, CommonJS, déclarations TypeScript et ressources. Cette adaptation permet de compiler ; elle ne rend pas les outils natifs d'export utilisables.
- **VPWeb :** installation sans scripts natifs, liaison au VPX-JS local, remplacement de `node-sass` par `sass@1.32.13`, puis compilation Webpack 4 avec `NODE_OPTIONS=--openssl-legacy-provider`. Le build réussit avec des avertissements upstream sur des exports de types Three.js et la taille des bundles.
- Le jeu MTB utilise une **nouvelle application hôte** légère fondée sur l'architecture de VPWeb : worker de physique et rendu Three.js séparés. VPWeb est livré comme référence de code. Ses grosses tables binaires et leurs captures sont exclues de l'archive ; les sources restantes ne sont donc pas un build autonome de VPWeb.
- `npm run build:upstream` reproduit les deux compilations dans un **nouveau** dossier `upstream-rebuild/`, en récupérant les dépôts complets aux commits ci-dessus. Il nécessite Git et Internet et refuse d'écraser un dossier de clone existant. Les adaptations sont visibles dans `scripts/rebuild-upstream.mjs` et les journaux dans `reports/`.

## Architecture et périmètre

- `src/engine.js` charge la table, instancie le véritable `Player`, crée/détruit la bille via son API et commande `RotateToEnd` / `RotateToStart`.
- `src/physics.worker.js` appelle `Player.updatePhysics`. Le pas interne, les collisions et les forces restent ceux de VPX-JS. Seule l'horloge de l'hôte borne les retards à 32 ms pour éviter le rattrapage d'une longue suspension Safari ; sous charge le jeu peut ralentir.
- `src/main.js` affiche un vrai volume 3D et applique les positions/angles calculés par le moteur. Les meshes visuels simples ne calculent aucune physique. Il n'y a pas de trajectoire prédéfinie ni de moteur alternatif.
- `src/input.js` suit chaque `pointerId` et chaque touche : capture du pointeur, sources indépendantes, annulation et libération au changement d'application. `touch-action: none` évite le défilement des boutons ; aucune limitation au premier doigt.
- Le lancement, la sortie de bille et l'interface sont des règles JavaScript de l'hôte. Le script VBScript de cette table n'est pas utilisé. La compatibilité avec des tables communautaires complexes, PinMAME, ROM, sons, scores, nudge et plongeur analogique est hors de ce prototype.

## Blocages et limites constatés

1. **Validation graphique incomplète ici.** Chromium installé se termine immédiatement au lancement (SIGTRAP / code 133). WebKit installé manque de bibliothèques Linux, notamment GStreamer. Les échecs sont conservés dans `reports/browser-results.json` ; aucune capture ni mesure Safari n'est présentée comme obtenue.
2. **Ancien port VPX.** Le code cible Visual Pinball 10.6 ; il ne représente pas toutes les évolutions de VPX moderne. L'égalité de comportement avec le moteur natif n'a pas été certifiée.
3. **Scripting et export upstream partiels.** Le build avertit sur l'utilisation de `eval` par le transpileur VBScript. Le prototype ne l'exécute pas. L'export GLTF navigateur est non implémenté et deux tests supplémentaires le montrent.
4. **Performances iPhone non mesurées.** Ratio de pixels plafonné à 1,5, meshes modestes et absence de gros effets, mais FPS, latence tactile, stabilité GPU et chauffe doivent être mesurés sur appareil réel.
5. **Jeu de test, pas encore arcade complète.** Plateau minimal sans bumpers, missions, score, son ou sauvegarde. L'objectif de cette livraison est de rendre vérifiables la physique VPX et les commandes multitouch avant d'étendre le jeu.

## Licences et redistribution

Le code MTB est fourni sous **GPL-2.0-or-later**. Les licences GPL et en-têtes d'origine de VPX-JS/VPWeb sont conservés dans `vendor/`. La distribution comprend les sources utilisées, le générateur de plateau, les scripts de compilation et les notices des dépendances. Consultez `LICENSE`, `THIRD_PARTY_NOTICES.txt` et les fichiers `*.LEGAL.txt` des bundles.

Three.js et les polyfills conservent leurs licences respectives. CFB (Apache-2.0) est un outil de génération indépendant, absent des bundles du jeu. Les tables commerciales et leurs captures présentes dans VPWeb, ainsi que toute ROM, ne sont pas livrées. N'ajoutez ou ne redistribuez d'autres plateaux/assets qu'avec les droits correspondants.

Si vous distribuez une version modifiée de ce programme, fournissez les sources correspondantes et conservez licences, notices et attributions applicables. Aucun composant propriétaire n'est nécessaire au plateau MTB de test.
