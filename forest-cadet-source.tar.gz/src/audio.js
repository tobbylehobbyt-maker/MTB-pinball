// SPDX-License-Identifier: GPL-2.0-or-later
// Original 96 BPM cinematic synthwave atmosphere, synthesized locally with Web Audio.
export function createForestAudio(button) {
 let ctx,master,delay,enabled=false,paused=true,timer,next=0,step=0,lastEvent=0;
 const beat=60/96, eighth=beat/2;
 const notes=[38,38,45,50,34,34,41,46,41,41,48,53,36,36,43,48];
 let volume=.35;
 const freq=n=>440*Math.pow(2,(n-69)/12);
 const tone=(hz,t,d,gain=.06,type='triangle',cutoff=2500)=>{
   const o=ctx.createOscillator(),g=ctx.createGain(),f=ctx.createBiquadFilter();o.type=type;o.frequency.value=hz;f.type='lowpass';f.frequency.setValueAtTime(cutoff,t);f.frequency.exponentialRampToValueAtTime(Math.max(180,cutoff*.3),t+d);
   g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(gain,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+d);
   o.connect(f);f.connect(g);g.connect(master);if(hz>250)g.connect(delay);o.start(t);o.stop(t+d+.02);
 };
 const pad=(notes,t,d)=>notes.forEach(n=>[-7,7].forEach(detune=>{
  const o=ctx.createOscillator(),g=ctx.createGain(),f=ctx.createBiquadFilter();o.type='sawtooth';o.frequency.value=freq(n);o.detune.value=detune;f.type='lowpass';f.frequency.setValueAtTime(650,t);f.frequency.linearRampToValueAtTime(1800,t+d*.6);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.012,t+.45);g.gain.setValueAtTime(.012,t+d-.7);g.gain.linearRampToValueAtTime(0,t+d);o.connect(f);f.connect(g);g.connect(master);g.connect(delay);o.start(t);o.stop(t+d+.05);
 }));
 const kick=t=>{const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.setValueAtTime(130,t);o.frequency.exponentialRampToValueAtTime(42,t+.14);g.gain.setValueAtTime(.27,t);g.gain.exponentialRampToValueAtTime(.0001,t+.25);o.connect(g);g.connect(master);o.start(t);o.stop(t+.27);};
 let noise;
 const percussion=(t,snare=false)=>{const n=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain();n.buffer=noise;f.type='highpass';f.frequency.value=snare?1200:6500;g.gain.setValueAtTime(snare?.065:.018,t);g.gain.exponentialRampToValueAtTime(.0001,t+(snare?.14:.055));n.connect(f);f.connect(g);g.connect(master);n.start(t);n.stop(t+.18);};
 const schedule=()=>{
   if(!enabled||paused)return;
   while(next<ctx.currentTime+.15){
     const i=step%32,t=next;
     const section=Math.floor(step/64)%4;
     if(i%4===0)kick(t);if(i%8===4&&section>0)percussion(t,true);if(section>1&&i%2===1)percussion(t+.012);
     tone(freq(notes[Math.floor(i/2)]),t,eighth*.85,.075,'triangle',750);
     const chord=[[50,57,62,65],[46,53,58,62],[53,60,65,69],[48,55,60,64]][Math.floor(i/8)];
     if(i%8===0)pad(chord,t,eighth*8+.8);
     const pattern=[0,1,2,3,2,1,3,2];
     tone(freq(chord[pattern[i%8]]+12),t,eighth*.7,section===0?.014:.025,'triangle',2600);
     if(section===3&&i%4===0)tone(freq(chord[(i/4)%4]+19),t,beat*1.7,.014,'sine',3400);
     step++;next+=eighth;
   }
   timer=setTimeout(schedule,40);
 };
 const start=()=>{clearTimeout(timer);next=ctx.currentTime+.05;schedule();};
 const setVolume=()=>{if(ctx)master.gain.setTargetAtTime(enabled&&!paused?volume:0,ctx.currentTime,.12);};
 button.addEventListener('click',async()=>{
  try{
   if(!ctx){ctx=new (window.AudioContext||window.webkitAudioContext)();master=ctx.createGain();master.gain.value=0;const comp=ctx.createDynamicsCompressor();comp.threshold.value=-16;comp.ratio.value=4;master.connect(comp);comp.connect(ctx.destination);
    delay=ctx.createDelay(1);delay.delayTime.value=eighth*1.5;const wet=ctx.createGain();wet.gain.value=.28;delay.connect(wet);wet.connect(master);
    noise=ctx.createBuffer(1,ctx.sampleRate*.2,ctx.sampleRate);const data=noise.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;
   }
   await ctx.resume();enabled=!enabled;setVolume();button.textContent=enabled?'♫ Ambiance : ON':'♫ Ambiance : OFF';button.setAttribute('aria-pressed',String(enabled));if(enabled&&!paused)start();else clearTimeout(timer);
  }catch{button.textContent='Audio indisponible';}
 });
 const slider=document.getElementById('music-volume');slider?.addEventListener('input',()=>{volume=Number(slider.value)/100;setVolume();});
 return {pause:value=>{paused=value;setVolume();if(ctx&&enabled&&!paused)start();else clearTimeout(timer);},event:state=>{if(state.eventId===lastEvent)return;lastEvent=state.eventId;if(enabled&&!paused&&ctx)[76,79,83].forEach((n,i)=>tone(freq(n),ctx.currentTime+.02+i*.1,.35,.025));}};
}
