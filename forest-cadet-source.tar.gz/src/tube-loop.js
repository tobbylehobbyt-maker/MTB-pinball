// Shared centerline for the visible tube and its guided arcade traversal.
export function tubeLoop(ramp){
  const points=ramp.left.map((p,i)=>({x:(p.x+ramp.right[i].x)/2,y:(p.y+ramp.right[i].y)/2,z:p.z+29}));
  const first=points[0],last=points[points.length-1];
  for(let i=1;i<=32;i++){const t=i/32,s=t*t*(3-2*t);points.push({x:last.x+(first.x-last.x)*s,y:last.y+(first.y-last.y)*s,z:last.z+(first.z-last.z)*s+Math.sin(Math.PI*t)*95});}
  let length=0;const distances=[0];for(let i=1;i<points.length;i++){length+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y,points[i].z-points[i-1].z);distances.push(length);}
  return {name:ramp.name,points,distances,length};
}
export function pointOnTube(loop,distance){
  const s=Math.max(0,Math.min(loop.length,distance));let i=1;while(i<loop.distances.length-1&&loop.distances[i]<s)i++;
  const a=loop.points[i-1],b=loop.points[i],span=loop.distances[i]-loop.distances[i-1],t=span?(s-loop.distances[i-1])/span:0;
  return {x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t};
}
