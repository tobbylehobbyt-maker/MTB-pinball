// SPDX-License-Identifier: GPL-2.0-or-later
import { Buffer } from 'buffer';
import process from 'process';
export { Buffer, process };
