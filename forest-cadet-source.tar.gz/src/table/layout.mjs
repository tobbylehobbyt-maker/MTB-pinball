// SPDX-License-Identifier: GPL-2.0-or-later
import * as THREE from 'three';
// Coordinates belong to the existing VPX 600 × 1100 table, not the reference image.
export const tracks=[
 {id:'LeftRamp',width:58,points:[[220,700,0],[210,660,4],[160,510,65],[120,370,140],[145,240,220],[235,190,265],[270,110,290],[190,60,300],[65,165,285],[48,335,250],[60,500,200],[110,650,120],[115,730,65],[115,810,30],[115,890,0]]},
 {id:'RightRamp',width:58,points:[[363,695,0],[375,650,4],[420,510,65],[455,385,140],[455,260,220],[410,175,280],[345,225,305],[390,325,300],[505,410,270],[503,550,200],[443,690,105],[442,790,45],[442,890,0]]},
];
export function sampleTrack(track){
 const curve=new THREE.CatmullRomCurve3(track.points.map(p=>new THREE.Vector3(...p)),false,'centripetal');
 return curve.getSpacedPoints(140).map(p=>[p.x,p.y,Math.max(0,p.z)*.7]);
}
export const laneDividers=[
 {name:'LeftLaneDivider',points:[[72,735],[78,729],[84,735],[84,965],[72,965]]},
 {name:'RightLaneDivider',points:[[472,735],[478,729],[484,735],[484,965],[472,965]]},
];
export const slingshots=[
 {name:'LeftGuide',points:[[145,720],[225,850],[145,850]]},
 {name:'RightGuide',points:[[410,720],[410,850],[330,850]]},
];
