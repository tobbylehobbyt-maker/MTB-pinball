// SPDX-License-Identifier: GPL-2.0-or-later
// Original synthesized cues, independent of the background music.
export function createEffects(button){
 let ctx,enabled=true,lastEvent=-1,lastContact=0,lastMetal=-Infinity,lastTube=null,lastPasses=0,seen={};
 const unlock=()=>{if(!ctx)ctx=new(window.AudioContext||window.webkitAudioContext)();ctx.resume().catch(()=>{});};
 window.addEventListener('pointerdown',unlock,{once:true});window.addEventListener('keydown',unlock,{once:true});
 const tone=(frequency,end,duration=.08,gain=.035,delay=0,type='triangle')=>{
  if(!enabled||!ctx||ctx.state!=='running')return;
  const now=ctx.currentTime+delay,o=ctx.createOscillator(),g=ctx.createGain();o.type=type;
  o.frequency.setValueAtTime(frequency,now);o.frequency.exponentialRampToValueAtTime(Math.max(20,end),now+duration);
  g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(gain,now+.006);g.gain.exponentialRampToValueAtTime(.0001,now+duration);
  o.connect(g);g.connect(ctx.destination);o.start(now);o.stop(now+duration);
 };
 const play=(f,d=.08,g=.035)=>tone(f,f*.45,d,g);
 const metal=()=>{if(!enabled||!ctx||ctx.state!=='running'||ctx.currentTime-lastMetal<.065)return;lastMetal=ctx.currentTime;for(const [f,a,d] of [[1450,.023,.12],[2370,.012,.075],[3910,.006,.045]])tone(f,f,d,a,0,'sine');};
 const tubeExit=()=>{tone(220,1300,.19,.04);tone(760,190,.25,.035,.17,'sine');tone(330,660,.1,.025,.36);};
 const cheer=(combo=1)=>{const notes=combo>=3?[523,659,784,1047,1319]:[392,523,659];notes.forEach((f,i)=>tone(f,f*1.015,.18,.028,i*.085,'square'));tone(160,60,.22,.035,0,'sine');};
 button.addEventListener('click',()=>{unlock();enabled=!enabled;button.textContent=enabled?'◉ Sons : ON':'◉ Sons : OFF';button.setAttribute('aria-pressed',String(enabled));});
 return {
  flip:(down=true)=>play(down?145:82,down?.055:.035,down?.03:.018),
  launch:()=>{unlock();play(240,.22,.045);},
  update:(s,paused)=>{
   if(s.collisions>lastContact&&!paused)metal();lastContact=s.collisions;
   if(lastTube&&!s.tubeRide&&s.rampPasses>lastPasses&&!paused)tubeExit();lastTube=s.tubeRide?.name||null;lastPasses=s.rampPasses;
   for(const [name,until]of Object.entries(s.flashes)){if(seen[name]!==until&&until>s.time&&!paused)play(name.startsWith('Bumper')?650:name.startsWith('Rock')?95:360,.09);seen[name]=until;}
   if(s.eventId!==lastEvent){lastEvent=s.eventId;if(!paused){
    if(/JACKPOT|COMBO/.test(s.event))cheer(s.combo);
    else if(/SKILL/.test(s.event)){tone(440,880,.16,.035);tone(880,1320,.18,.03,.15);}
    else if(/TURBO TUBE/.test(s.event))tone(100,600,.3,.03,0,'sine');
    else if(/Mission|TRAIL/.test(s.event))cheer();
    else if(/TILT/.test(s.event))tone(180,45,.35,.03,0,'sawtooth');
   }}
  }
 };
}
