// SPDX-License-Identifier: GPL-2.0-or-later
// VPWeb architecture: Player in a worker, Three.js rendering on the UI thread.
import { createEngine } from './engine.js';
let engine, timer, running = false, simTime = 0, lastTime = 0, cycles = 0, lastReport = 0;
let pendingFrame = false;
const postState = () => { const state = engine.snapshot(); delete state.ramps; postMessage({ type: 'state', state, cycles }); };
function tick() {
  if (!engine || !running) return;
  const time = performance.now();
  // Host clock clamps long Safari suspensions; VPX's fixed physics tick stays intact.
  simTime += Math.min(32, Math.max(0, time - lastTime)); lastTime = time;
  cycles += engine.player.updatePhysics(simTime);
  engine.updateRules();
  engine.player.updateAnimations(engine.player.getGameTime());
  const ball = engine.player.balls[0];
  if (ball && engine.isDraining()) {
    if(engine.drain()){if(!engine.snapshot().gameOver)engine.stage();postMessage({type:'drain'});postState();}
  }
  if (pendingFrame || time - lastReport > 1000) {
    postState(); pendingFrame = false; lastReport = time;
  }
  timer = setTimeout(tick, 4);
}
self.onmessage = async ({ data }) => {
  try {
    if (data.type === 'init') {
      engine = await createEngine(data.blob);
      engine.player.updatePhysics(0);engine.stage();
      postMessage({ type: 'ready', state: engine.snapshot() });
      return;
    }
    if (!engine) return;
    if(data.type==='nudge'){engine.nudge(data.direction);postState();}
    if(data.type==='mode'){engine.setMode(data.mode);postState();}
    if(data.type==='newGame'){engine.newGame();postState();}
    if (data.type === 'launch') { engine.fire(data.power ?? 1); postState(); }
    if (data.type === 'stage') {engine.stage();postState();}
    if (data.type === 'flip') engine.flip(data.side, data.down);
    if (data.type === 'frame') { pendingFrame = true; if (!running) postState(); }
    if (data.type === 'pause') {
      running = false; clearTimeout(timer);
      engine.flip('left', false); engine.flip('right', false);
      postState();
    }
    if (data.type === 'resume' && !running) { running = true; lastTime = performance.now(); tick(); }
  } catch (error) { running = false; clearTimeout(timer); postMessage({ type: 'error', error: error.stack || String(error) }); }
};
