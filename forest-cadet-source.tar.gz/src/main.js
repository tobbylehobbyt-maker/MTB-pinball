// SPDX-License-Identifier: GPL-2.0-or-later
import * as THREE from 'three';
import { tubeLoop } from './tube-loop.js';
import { createForestAudio } from './audio.js';
import { createEffects } from './effects.js';
import { bindInputs } from './input.js';
import { createLeaderboard } from './leaderboard.js';
const $ = id => document.getElementById(id);
const status = $('status'), canvas = $('table'), start = $('launch'), pauseButton = $('pause');
const audio=createForestAudio($('music'));
const effects=createEffects($('sfx'));
const leaderboard=createLeaderboard(()=>{if(ready)setPaused();});
let bestScore=0,lastAnnouncement=-1,lastMode='',lastCelebration='';const records={arcade:0,classic:0};try{records.arcade=Number(localStorage.getItem('forest-cadet-best'))||0;records.classic=Number(localStorage.getItem('forest-cadet-best-classic'))||0;}catch{}
$('mode').addEventListener('click',()=>{send({type:'mode',mode:latest?.mode==='classic'?'arcade':'classic'});resume();});
$('nudge').addEventListener('click',()=>send({type:'nudge'}));
window.addEventListener('keydown',e=>{if(e.target.closest?.('input,select,textarea,dialog[open]')||document.querySelector('dialog[open]'))return;if(['KeyN','KeyZ','KeyX'].includes(e.code)&&!e.repeat){e.preventDefault();send({type:'nudge',direction:e.code==='KeyZ'?'left':e.code==='KeyX'?'right':'up'});}});
$('new-game').addEventListener('click',()=>{send({type:'newGame'});resume();});
const arcadeMeshes={},bumperMechanisms={},insertGroups={};
let springMesh, charging=false,chargeStart=0;
let worker, ready = false, paused = true, latest, renderer, scene, camera, ballMesh, flipperMeshes = {}, framePending = false;
let frameCount = 0, fpsStart = performance.now(), fps = 0;
const debug = window.MTB = { engine: 'VPX-JS 1.3.4 / Visual Pinball 10.6 port', ready: false, state: null, errors: [], fps: 0 };
function fail(error) {
  debug.errors.push(String(error)); status.textContent = `Erreur : ${error.message || error}`;
  $('loading').textContent = 'Le plateau n’a pas démarré. Voir le diagnostic ci-dessus.';
  start.disabled = true; pauseButton.disabled = true;
}
let introStart=null;
const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
function finishIntro(){introStart=null;document.body.classList.remove('cabinet-arrival');if(camera){camera.zoom=1;camera.position.set(300,1220,2400);camera.lookAt(300,550,0);camera.updateProjectionMatrix();}}
const send = message => { if (ready) worker.postMessage(message); };
const inputs = bindInputs({ left: $('left'), right: $('right'), send: (side, down) => {send({ type: 'flip', side, down });effects.flip(down);}, launch, charge:beginCharge, release:releaseCharge, pause: togglePause });
function beginCharge() {
  if(!ready || charging || (latest?.ball&&!latest.staged))return;
  if(latest?.gameOver)send({type:'newGame'});
  charging=true;chargeStart=performance.now();
  send({type:'stage'});resume();$('loading').hidden=true;
  start.classList.add('charging');$('launch-label').textContent='Relâcher pour lancer';
}
function releaseCharge() {
  if(!charging)return;
  const power=Math.min(1,(performance.now()-chargeStart)/1100);
  charging=false;start.classList.remove('charging');
  send({type:'launch',power});effects.launch();resume();$('launch-label').textContent='Nouvelle bille';
}
function launch(){if(!ready||(latest?.ball&&!latest.staged))return;if(latest?.gameOver)send({type:'newGame'});send({type:'launch',power:1});effects.launch();resume();$('loading').hidden=true;$('launch-label').textContent='Nouvelle bille';}
function resume() { if (!ready) return; finishIntro(); paused = false; audio.pause(false); send({ type: 'resume' }); pauseButton.textContent = 'Pause'; }
function setPaused() { charging=false; start.classList.remove('charging'); inputs.clear(); paused = true; audio.pause(true); send({ type: 'pause' }); pauseButton.textContent = 'Reprendre'; }
function togglePause() { paused ? resume() : setPaused(); }
start.addEventListener('pointerdown',e=>{e.preventDefault();start.setPointerCapture(e.pointerId);beginCharge();});
start.addEventListener('pointerup',releaseCharge);
start.addEventListener('pointercancel',()=>{charging=false;start.classList.remove('charging');$('launch-label').textContent='Tirer / relâcher';});
start.addEventListener('click',e=>{if(e.detail===0)launch();}); pauseButton.addEventListener('click', togglePause);
document.addEventListener('visibilitychange', () => { if (document.hidden) setPaused(); });
window.addEventListener('blur', () => { if (ready) setPaused(); });
const envCanvas=document.createElement('canvas');envCanvas.width=512;envCanvas.height=256;
const envCtx=envCanvas.getContext('2d'),envGradient=envCtx.createLinearGradient(0,0,512,256);
envGradient.addColorStop(0,'#fff4fc');envGradient.addColorStop(.15,'#24143d');envGradient.addColorStop(.38,'#53d8ff');envGradient.addColorStop(.5,'#ffffff');envGradient.addColorStop(.56,'#10091c');envGradient.addColorStop(.8,'#ff8ace');envGradient.addColorStop(1,'#e6efff');envCtx.fillStyle=envGradient;envCtx.fillRect(0,0,512,256);
for(const [x,w,color] of [[30,80,'#080810'],[115,14,'#ffffff'],[210,100,'#11121e'],[318,9,'#ffffff'],[400,30,'#eefaff'],[460,35,'#090815']]){envCtx.fillStyle=color;envCtx.fillRect(x,0,w,256);}
const envMap=new THREE.CanvasTexture(envCanvas);envMap.mapping=THREE.EquirectangularReflectionMapping;
function material(color, metalness = .15) { return new THREE.MeshStandardMaterial({ color, roughness: metalness>.5 ? .12 : .55, envMap, metalness }); }
function extrude(points, height, color) {
  const shape = new THREE.Shape(); shape.moveTo(points[0].x, points[0].y);
  points.slice(1).forEach(p => shape.lineTo(p.x, p.y)); shape.closePath();
  return new THREE.Mesh(new THREE.ExtrudeBufferGeometry(shape, { depth: height, bevelEnabled: false, steps: 1 }), material(color));
}
function initScene(state) {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); renderer.setClearColor(0x080419);
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  scene = new THREE.Scene();scene.scale.x=-1;scene.position.x=600;
  scene.add(new THREE.HemisphereLight(0xb9e3ff, 0x24283b, .85));
  const light = new THREE.DirectionalLight(0xffffff, 1.25); light.position.set(100, 450, 1200);light.castShadow=true;light.shadow.mapSize.set(2048,2048);Object.assign(light.shadow.camera,{left:-800,right:800,top:850,bottom:-850,near:1,far:2500});light.shadow.bias=-.0002;scene.add(light);
  camera = new THREE.OrthographicCamera(-330,330,605,-605,1,6000); camera.up.set(0, 0, 1);
  const board = new THREE.Mesh(new THREE.BoxBufferGeometry(state.width, state.height, 20), material(0x161020));
  board.position.set(state.width/2,state.height/2,-10);scene.add(board);
  const art=new THREE.TextureLoader().load('./synthwave-playfield.png');art.flipY=false;art.anisotropy=renderer.capabilities.getMaxAnisotropy();
  const print=new THREE.Mesh(new THREE.PlaneBufferGeometry(600,1100),new THREE.MeshStandardMaterial({map:art,roughness:.42,metalness:.08}));
  print.position.set(300,550,.5);print.receiveShadow=true;scene.add(print);
  const chrome=new THREE.MeshStandardMaterial({color:0xc7daf0,metalness:.95,roughness:.09,envMap});
  const glow=color=>new THREE.MeshBasicMaterial({color});
  const tube=(points,radius,mat)=>{const path=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));const m=new THREE.Mesh(new THREE.TubeBufferGeometry(path,Math.max(160,points.length*2),radius,12,false),mat);m.castShadow=true;scene.add(m);return m;};
  for(const x of [8,592]){
    tube([[x,0,90],[x,400,90],[x,1090,90]],5,chrome);
    tube([[x,0,84],[x,400,84],[x,1090,84]],2,glow(x<300?0xff28ca:0x40e7ff));
  }
  const ribbon=(edgeA,edgeB,mat)=>{
    const verts=[],indices=[],uvs=[];
    for(let i=0;i<edgeA.length;i++){const a=edgeA[i],b=edgeB[i];verts.push(a.x,a.y,a.z,b.x,b.y,b.z);uvs.push(0,i*.22,1,i*.22);if(i<edgeA.length-1){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2);}}
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);geometry.computeVertexNormals();const m=new THREE.Mesh(geometry,mat);scene.add(m);return m;
  };
  // Packed earth, granular bump detail and two worn tire lines.
  const dirtCanvas=document.createElement('canvas');dirtCanvas.width=dirtCanvas.height=256;
  const dc=dirtCanvas.getContext('2d');dc.fillStyle='#886744';dc.fillRect(0,0,256,256);
  let noiseSeed=8341;const noise=()=>{noiseSeed=(noiseSeed*1664525+1013904223)>>>0;return noiseSeed/4294967296;};
  for(let i=0;i<13000;i++){const n=noise();dc.fillStyle=n>.5?'rgba(218,188,141,.22)':'rgba(43,32,23,.2)';dc.fillRect(noise()*256,noise()*256,1+noise()*3,1+noise()*2);}
  for(const x of [96,152]){dc.strokeStyle='rgba(40,31,24,.35)';dc.lineWidth=8;dc.beginPath();dc.moveTo(x,0);dc.bezierCurveTo(x-4,80,x+6,180,x,256);dc.stroke();for(let y=0;y<256;y+=12){dc.fillStyle='rgba(32,27,22,.28)';dc.fillRect(x-6,y,12,2);}}
  const dirtTexture=new THREE.CanvasTexture(dirtCanvas);dirtTexture.wrapS=dirtTexture.wrapT=THREE.RepeatWrapping;dirtTexture.anisotropy=8;
  const earth=new THREE.MeshStandardMaterial({color:0x574333,roughness:1,metalness:0,flatShading:true,side:THREE.DoubleSide});
  const stone=new THREE.MeshStandardMaterial({color:0x655d50,roughness:1,metalness:0,flatShading:true});
  // Local cutaways preserve the physical track while exposing important devices below it.
  const revealTargets=[...state.bumpers.map(b=>[b.x,b.y-77*.28,56]),...state.boostZones.map(b=>[b.x,b.y,48])];
  function revealMechanisms(mat){
    mat.transparent=true;mat.depthWrite=false;
    mat.onBeforeCompile=shader=>{
      shader.vertexShader='varying vec2 trackProjection;\n'+shader.vertexShader;
      shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\ntrackProjection=vec2(position.x,position.y-position.z*.28);');
      shader.fragmentShader='varying vec2 trackProjection;\n'+shader.fragmentShader;
      const masks=revealTargets.map(([x,y,r])=>`visibility=min(visibility,mix(.12,1.,smoothstep(${r-10}.0,${r+12}.0,distance(trackProjection,vec2(${x.toFixed(2)},${y.toFixed(2)})))));`).join('\n');
      shader.fragmentShader=shader.fragmentShader.replace('#include <dithering_fragment>',`float visibility=1.;\n${masks}\ngl_FragColor.a*=visibility;\n#include <dithering_fragment>`);
    };
    return mat;
  }
  revealMechanisms(earth);
  for(const r of state.ramps){
    const glass=new THREE.MeshPhysicalMaterial({color:0x8b36d6,transparent:true,opacity:.16,metalness:.05,roughness:.08,side:THREE.DoubleSide,depthWrite:false,envMap});
    const floorMaterial=new THREE.MeshPhysicalMaterial({color:0x8cd7e4,transparent:true,opacity:.12,roughness:.08,metalness:.08,envMap,side:THREE.DoubleSide,depthWrite:false});
    ribbon(r.left.map(p=>({...p,z:p.z+1.2})),r.right.map(p=>({...p,z:p.z+1.2})),floorMaterial);
    glass.opacity=.065;
    // Soft contact shadows anchor the elevated track without obscuring the printed artwork.
    const shadowCanvas=document.createElement('canvas');shadowCanvas.width=64;shadowCanvas.height=64;
    const shadowCtx=shadowCanvas.getContext('2d'),shade=shadowCtx.createRadialGradient(32,32,3,32,32,32);
    shade.addColorStop(0,'rgba(8,4,18,.45)');shade.addColorStop(1,'rgba(8,4,18,0)');shadowCtx.fillStyle=shade;shadowCtx.fillRect(0,0,64,64);
    const shadowMat=new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(shadowCanvas),transparent:true,depthWrite:false});
    for(let i=4;i<r.left.length-4;i+=5){const a=r.left[i],b=r.right[i];if(a.z<20)continue;const shadow=new THREE.Mesh(new THREE.PlaneBufferGeometry(85,65),shadowMat);shadow.position.set((a.x+b.x)/2+8,(a.y+b.y)/2+9,1);scene.add(shadow);}

    for(const edge of [r.left,r.right]){
      const edgeIndex=edge===r.left?0:1,opposite=edgeIndex?r.left:r.right;
      const shoulder=edge.map((p,i)=>{const q=opposite[i],d=Math.hypot(p.x-q.x,p.y-q.y);const relief=6+12*Math.pow(Math.sin(Math.PI*i/(edge.length-1)),2);return {x:p.x+(p.x-q.x)/d*.8,y:p.y+(p.y-q.y)/d*.8,z:p.z+relief};});
      const outer=edge.map((p,i)=>{const q=opposite[i],d=Math.hypot(p.x-q.x,p.y-q.y);return {x:p.x+(p.x-q.x)/d*1.6,y:p.y+(p.y-q.y)/d*1.6,z:Math.max(1,p.z-14)};});
      ribbon(edge,shoulder,floorMaterial);
      ribbon(shoulder,outer,floorMaterial);
      ribbon(edge,edge.map(p=>({...p,z:Math.max(1,p.z-18)})),floorMaterial);
      // Track boundary remains inside the native collision wall; terrain is scenery outside it.
      tube(edge.map(p=>[p.x,p.y,p.z+5 ]),.75,chrome);
      for(let i=5;i<edge.length-5;i+=6){const p=shoulder[i];const rock=new THREE.Mesh(new THREE.IcosahedronBufferGeometry(2+noise()*2,1),stone);rock.position.set(p.x,p.y,p.z-3);rock.scale.set(1.4,.8,.7);rock.castShadow=true;scene.add(rock);}
      const upper=edge.map(p=>({...p,z:p.z+34}));
      tube(upper.map(p=>[p.x,p.y,p.z]),.85,chrome);
      for(let i=10;i<edge.length-10;i+=18){const p=edge[i];const lamp=new THREE.Mesh(new THREE.SphereBufferGeometry(2,10,8),glow(0xffa52b));lamp.position.set(p.x,p.y,p.z+12);scene.add(lamp);}
      for(let i=6;i<edge.length-6;i+=13){const p=edge[i];tube([[p.x,p.y,p.z+5],[p.x,p.y,p.z+38]],.9,chrome);}
      for(let i=12;i<edge.length-12;i+=18){const p=edge[i];if(p.z>70){const support=new THREE.Mesh(new THREE.CylinderBufferGeometry(2.2,3,p.z,10),chrome);support.rotation.x=Math.PI/2;support.position.set(p.x,p.y,p.z/2);support.castShadow=true;scene.add(support);
        const foot=new THREE.Mesh(new THREE.CylinderBufferGeometry(6,7,3,20),chrome);foot.rotation.x=Math.PI/2;foot.position.set(p.x,p.y,3);foot.castShadow=true;scene.add(foot);
        const collar=new THREE.Mesh(new THREE.CylinderBufferGeometry(4,4,5,16),chrome);collar.rotation.x=Math.PI/2;collar.position.set(p.x,p.y,p.z-5);scene.add(collar);
      }}
    }
    // Cross ties and bolted wooden sections sit on the same physical ramp surface.
    for(let i=8;i<r.left.length-8;i+=8){const a=r.left[i],b=r.right[i];tube([[a.x,a.y,a.z-3],[b.x,b.y,b.z-3]],.7,chrome);}
    insertGroups[r.name]=[];
    for(let i=3;i<r.left.length-4;i+=12){
      const a=r.left[i],b=r.right[i],a1=r.left[i+1],b1=r.right[i+1];
      const arrow=extrude([{x:-8,y:10},{x:0,y:-7},{x:8,y:10},{x:0,y:5}],1,0xff9b28);
      arrow.position.set((a.x+b.x)/2,(a.y+b.y)/2,a.z+3);arrow.rotation.z=Math.atan2((a1.y+b1.y-a.y-b.y),(a1.x+b1.x-a.x-b.x))+Math.PI/2;
      arrow.material=new THREE.MeshBasicMaterial({color:0xff8a18,transparent:true,opacity:.45});scene.add(arrow);insertGroups[r.name].push(arrow);
    }
    const entry=r.left[0],other=r.right[0];
    for(let i=0;i<3;i++){const arrow=extrude([{x:-12,y:14},{x:0,y:-5},{x:12,y:14},{x:0,y:7}],1,0x9dff28);arrow.position.set((entry.x+other.x)/2,(entry.y+other.y)/2+38+i*25,2);scene.add(arrow);}
  }
  // Continuous clear accelerator tubes; rings follow the same centerline as the ball.
  for(const ramp of state.ramps){
    const loop=tubeLoop(ramp),curve=new THREE.CatmullRomCurve3(loop.points.map(p=>new THREE.Vector3(p.x,p.y,p.z)),false,'centripetal');
    const shell=new THREE.Mesh(new THREE.TubeBufferGeometry(curve,320,28,16,false),new THREE.MeshPhysicalMaterial({color:0x86dbf7,transparent:true,opacity:.065,roughness:.12,metalness:.05,envMap,side:THREE.DoubleSide,depthWrite:false}));scene.add(shell);
    for(let i=0;i<=40;i++){const t=i/40,p=curve.getPointAt(t),tangent=curve.getTangentAt(t);const ring=new THREE.Mesh(new THREE.TorusBufferGeometry(28,.7,6,32),chrome);ring.position.copy(p);ring.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),tangent);scene.add(ring);}
    const inlet=loop.points[0];const halo=new THREE.Mesh(new THREE.TorusBufferGeometry(29,1.5,8,40),glow(0x00dfff));halo.position.set(inlet.x,inlet.y,inlet.z);halo.rotation.x=Math.PI/2;scene.add(halo);
  }
  // Visible plunger at the bottom of the left outlane identifies the kickback.
  const kickbackBase=new THREE.Mesh(new THREE.BoxBufferGeometry(38,14,12),chrome);kickbackBase.position.set(38,944,12);scene.add(kickbackBase);
  for(let i=0;i<4;i++){const rib=new THREE.Mesh(new THREE.BoxBufferGeometry(30,2,6),material(0x263c43,.6));rib.position.set(38,927+i*4,13);scene.add(rib);}
  const kickbackArrow=extrude([{x:27,y:915},{x:38,y:899},{x:49,y:915},{x:38,y:910}],1,0x00dfff);kickbackArrow.material=glow(0x00dfff);kickbackArrow.position.z=3;scene.add(kickbackArrow);arcadeMeshes.Kickback=kickbackArrow;
  const coil=[];for(let i=0;i<=240;i++){const t=i/240;coil.push([575+Math.cos(t*Math.PI*24)*12,1020+t*65,30+Math.sin(t*Math.PI*24)*12]);}
  springMesh=tube(coil,2.5,chrome);
  const handle=new THREE.Mesh(new THREE.SphereBufferGeometry(16,20,16),chrome);handle.position.set(575,1090,30);scene.add(handle);

  // Cabinet rim, stainless lockbar, screws and a subtle protective glass sheet.
  const cabinetMat=new THREE.MeshStandardMaterial({color:0x13121b,metalness:.45,roughness:.55}),rubberMat=material(0x08070d,.1);
  const box=(w,h,d,x,y,z,mat)=>{const m=new THREE.Mesh(new THREE.BoxBufferGeometry(w,h,d),mat);m.position.set(x,y,z);scene.add(m);return m;};
  box(704,1170,160,300,550,-120,cabinetMat);
  for(const x of [-28,628]){
    box(24,1170,145,x,550,30,cabinetMat);
    box(9.5,1170,10,x,550,108,chrome);
    box(2.5,1150,8,x+(x<300?7:-7),550,107,glow(x<300?0xff28b8:0x23dfff));
    box(3.5,1120,12,x+(x<300?-6:6),550,111,rubberMat);
    for(const y of [20,280,550,820,1095]){
      const screw=new THREE.Mesh(new THREE.CylinderBufferGeometry(5,5,3,16),chrome);screw.rotation.x=Math.PI/2;screw.position.set(x,y,116);scene.add(screw);
      box(6,1,1,x,y,118,rubberMat);
    }
  }
  box(704,19,125,300,-28,35,cabinetMat);
  box(704,25,40,300,1140,99,chrome);
  box(690,3.5,6,300,1117,120,rubberMat);
  box(688,3,8,300,1157,124,glow(0xe533be));
  const apron=extrude([{x:15,y:1038},{x:180,y:1000},{x:300,y:1070},{x:420,y:1000},{x:585,y:1038},{x:585,y:1100},{x:15,y:1100}],8,0x211329);scene.add(apron);
  const glass=new THREE.Mesh(new THREE.PlaneBufferGeometry(600,1100),new THREE.MeshPhysicalMaterial({color:0xc1e5ff,transparent:true,opacity:.025,roughness:.04,metalness:.1,depthWrite:false,envMap}));
  glass.position.set(300,550,450);scene.add(glass);
  const rails = [[-4,550,8,1100],[604,550,8,1100],[300,-4,600,8]];
  for (const [x,y,w,h] of rails) { const m = new THREE.Mesh(new THREE.BoxBufferGeometry(w,h,80), material(0x31113e,.8)); m.position.set(x,y,40); scene.add(m); }
  for (const wall of state.walls) {
    const rock=wall.name.startsWith('Rock');
    const sling=['LeftGuide','RightGuide'].includes(wall.name);
    const mesh=extrude(wall.points,wall.height,rock ? 0x35474c : wall.name.startsWith('Target') ? 0xffb442 : 0x233d37);
    scene.add(mesh);arcadeMeshes[wall.name]=mesh;
    if(wall.name.includes('WoodGuide')){
      mesh.material=new THREE.MeshStandardMaterial({color:0x976238,roughness:.85,metalness:0});
      const a=wall.points[0],b=wall.points[2],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);
      for(let k=1;k<=3;k++){const offset=(k-2)*2;const nx=-dy/d,ny=dx/d;tube([[a.x+nx*offset,a.y+ny*offset,wall.height+.5],[b.x+nx*offset,b.y+ny*offset,wall.height+.5]],.45,material(0x50351f,.9));}
      for(const p of [a,b]){const screw=new THREE.Mesh(new THREE.CylinderBufferGeometry(2.2,2.2,2,12),chrome);screw.rotation.x=Math.PI/2;screw.position.set(p.x,p.y,wall.height+2);mesh.add(screw);}
    }
    if(wall.name.startsWith('Target')){
      mesh.material=new THREE.MeshStandardMaterial({color:0xffc958,metalness:.65,roughness:.2,envMap});
      const x=wall.points.reduce((n,p)=>n+p.x,0)/wall.points.length,y=wall.points.reduce((n,p)=>n+p.y,0)/wall.points.length;
      const face=new THREE.Mesh(new THREE.PlaneBufferGeometry(18,45),new THREE.MeshStandardMaterial({color:0x2e174d,metalness:.4,roughness:.25,envMap,side:THREE.DoubleSide}));face.rotation.x=Math.PI/2;face.position.set(x,y+8.5,48);mesh.add(face);
      const badge=new THREE.Mesh(new THREE.TorusBufferGeometry(5,1.4,8,24),glow(0xffd54b));badge.rotation.x=Math.PI/2;badge.position.set(x,y+9,48);mesh.add(badge);
      const base=new THREE.Mesh(new THREE.BoxBufferGeometry(29,21,5),chrome);base.position.set(x,y,3);scene.add(base);
    }
    if(sling){
      const left=wall.name.startsWith('Left'),accent=left?0xff2dbb:0xffe34a;
      const cx=wall.points.reduce((n,p)=>n+p.x,0)/3,cy=wall.points.reduce((n,p)=>n+p.y,0)/3;
      const inset=scale=>wall.points.map(p=>({x:cx+(p.x-cx)*scale,y:cy+(p.y-cy)*scale}));
      const rounded=(points,radius)=>{const sh=new THREE.Shape();const corners=points.map((p,i)=>{const prev=points[(i+2)%3],next=points[(i+1)%3];const d1=Math.hypot(prev.x-p.x,prev.y-p.y),d2=Math.hypot(next.x-p.x,next.y-p.y);return {p,a:{x:p.x+(prev.x-p.x)*radius/d1,y:p.y+(prev.y-p.y)*radius/d1},b:{x:p.x+(next.x-p.x)*radius/d2,y:p.y+(next.y-p.y)*radius/d2}};});sh.moveTo(corners[0].a.x,corners[0].a.y);for(const c of corners){sh.lineTo(c.a.x,c.a.y);sh.quadraticCurveTo(c.p.x,c.p.y,c.b.x,c.b.y);}sh.closePath();return sh;};
      mesh.material=new THREE.MeshStandardMaterial({color:0x080911,roughness:.25,metalness:.8,envMap});
      const rimGeometry=new THREE.ExtrudeBufferGeometry(rounded(inset(.97),9),{depth:8,bevelEnabled:true,bevelThickness:3,bevelSize:2,bevelSegments:4,steps:1});
      const rim=new THREE.Mesh(rimGeometry,chrome);rim.position.z=wall.height;mesh.add(rim);
      const border=new THREE.Mesh(new THREE.ExtrudeBufferGeometry(rounded(inset(.9),8),{depth:2,bevelEnabled:true,bevelThickness:1,bevelSize:1,bevelSegments:3}),new THREE.MeshStandardMaterial({color:accent,emissive:accent,emissiveIntensity:.9,metalness:.3,roughness:.15,envMap}));border.position.z=wall.height+9;mesh.add(border);
      const panelPoints=inset(.74),panelGeometry=new THREE.ExtrudeBufferGeometry(rounded(panelPoints,6),{depth:1,bevelEnabled:true,bevelThickness:1,bevelSize:1,bevelSegments:3});
      const minX=Math.min(...panelPoints.map(p=>p.x)),maxX=Math.max(...panelPoints.map(p=>p.x)),minY=Math.min(...panelPoints.map(p=>p.y)),maxY=Math.max(...panelPoints.map(p=>p.y));
      const uv=panelGeometry.attributes.uv,positions=panelGeometry.attributes.position;for(let i=0;i<uv.count;i++)uv.setXY(i,(positions.getX(i)-minX)/(maxX-minX),(positions.getY(i)-minY)/(maxY-minY));uv.needsUpdate=true;
      const textureCanvas=document.createElement('canvas');textureCanvas.width=256;textureCanvas.height=512;const ctx=textureCanvas.getContext('2d');ctx.fillStyle='#03050e';ctx.fillRect(0,0,256,512);
      const bolts=[[[115,45],[142,103],[90,169],[157,231],[83,303],[142,370],[100,455]],[[142,103],[193,125],[217,181]],[[90,169],[45,204],[32,266]],[[157,231],[221,280],[235,334]],[[83,303],[38,342],[30,408]],[[142,370],[208,405],[226,462]]];
      for(const bolt of bolts){ctx.beginPath();bolt.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));for(const [width,color,blur] of [[10,'#2358ff',20],[4,'#60dcff',9],[1.5,'#ecfbff',2]]){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.shadowColor=color;ctx.shadowBlur=blur;ctx.stroke();}}
      const texture=new THREE.CanvasTexture(textureCanvas);texture.anisotropy=8;
      const face=new THREE.Mesh(panelGeometry,new THREE.MeshPhysicalMaterial({color:0xffffff,map:texture,emissive:0x7ecfff,emissiveMap:texture,emissiveIntensity:.75,roughness:.12,metalness:.3,clearcoat:1,clearcoatRoughness:.04,envMap}));face.position.z=wall.height+12;mesh.add(face);mesh.userData.slingFace=face;
      for(const p of inset(.78)){
        for(const [radius,height,z,mat] of [[7,4,wall.height+12,chrome],[5.8,5,wall.height+16,material(0x15131c,.7)],[5,2,wall.height+20,chrome]]){const cap=new THREE.Mesh(new THREE.CylinderBufferGeometry(radius,radius,height,32),mat);cap.rotation.x=Math.PI/2;cap.position.set(p.x,p.y,z);mesh.add(cap);}
        const ring=new THREE.Mesh(new THREE.TorusBufferGeometry(6.8,.7,8,32),new THREE.MeshBasicMaterial({color:accent}));ring.position.set(p.x,p.y,wall.height+14);mesh.add(ring);
      }
    }
    if(wall.name.includes('Divider')){const pts=wall.points.map(p=>[p.x,p.y,wall.height+2]);pts.push(pts[0]);tube(pts,2,chrome);}
    if (rock) {
      const x=wall.points.reduce((n,p)=>n+p.x,0)/wall.points.length;
      const y=wall.points.reduce((n,p)=>n+p.y,0)/wall.points.length;
      const top=new THREE.Mesh(new THREE.IcosahedronBufferGeometry(35,1),new THREE.MeshStandardMaterial({color:0x536368,roughness:1,metalness:0,flatShading:true}));
      top.position.set(x,y,75); top.scale.z=.65;top.castShadow=true;scene.add(top);
    }
  }
  const capCanvas=document.createElement('canvas');capCanvas.width=256;capCanvas.height=256;
  const c=capCanvas.getContext('2d');const grad=c.createRadialGradient(100,80,10,128,128,125);grad.addColorStop(0,'#7e3d97');grad.addColorStop(.7,'#391449');grad.addColorStop(1,'#140c25');c.fillStyle=grad;c.fillRect(0,0,256,256);
  c.strokeStyle='#ff7edb';c.lineWidth=8;c.beginPath();c.arc(128,128,108,0,Math.PI*2);c.stroke();
  c.fillStyle='#ffe886';c.beginPath();c.moveTo(50,160);c.lineTo(100,91);c.lineTo(124,120);c.lineTo(159,75);c.lineTo(211,160);c.lineTo(158,126);c.lineTo(143,142);c.lineTo(103,126);c.closePath();c.fill();
  const capTexture=new THREE.CanvasTexture(capCanvas);
  for(const b of state.bumpers) {
    const cylinder=(radius,height,z,mat)=>{const m=new THREE.Mesh(new THREE.CylinderBufferGeometry(radius,radius,height,40),mat);m.rotation.x=Math.PI/2;m.position.set(b.x,b.y,z);m.castShadow=true;scene.add(m);return m;};
    cylinder(b.radius+8,8,5,chrome);
    cylinder(b.radius,25,22,material(0x17101c,.6));
    cylinder(b.radius-2,16,21,new THREE.MeshPhysicalMaterial({color:0xff8718,emissive:0xff5700,emissiveIntensity:.7,roughness:.2,metalness:.15,envMap}));
    for(const z of [12,30,55,61]){const band=new THREE.Mesh(new THREE.TorusBufferGeometry(b.radius+(z>40?1:3),2,12,64),chrome);band.position.set(b.x,b.y,z);scene.add(band);}
    for(let i=0;i<8;i++){const t=i*Math.PI/4;const bolt=new THREE.Mesh(new THREE.CylinderBufferGeometry(2.5,2.5,7,12),chrome);bolt.rotation.x=Math.PI/2;bolt.position.set(b.x+Math.cos(t)*(b.radius+5),b.y+Math.sin(t)*(b.radius+5),10);scene.add(bolt);}
    const winding=[];for(let i=0;i<=120;i++){const t=i/120;winding.push([b.x+Math.cos(t*Math.PI*12)*18,b.y+Math.sin(t*Math.PI*12)*18,32+t*24]);}tube(winding,1.5,chrome);
    cylinder(b.radius-10,24,43,chrome);
    const skirt=cylinder(b.radius+3,6,28,material(0xf8ecd4,.1));
    const ring=new THREE.Mesh(new THREE.TorusBufferGeometry(b.radius+1,5,12,48),chrome);ring.position.set(b.x,b.y,36);scene.add(ring);
    const neon=new THREE.Mesh(new THREE.TorusBufferGeometry(b.radius+6,2.2,8,48),glow(0xffbb42));neon.position.set(b.x,b.y,9);scene.add(neon);
    cylinder(b.radius+4,10,64,chrome);
    const cap=new THREE.Mesh(new THREE.SphereBufferGeometry(b.radius+3,40,20),material(0x5b175e,.35));cap.scale.z=.22;cap.position.set(b.x,b.y,69);scene.add(cap);arcadeMeshes[b.name]=cap;
    const badge=new THREE.Mesh(new THREE.CircleBufferGeometry(b.radius-2,40),new THREE.MeshPhysicalMaterial({map:capTexture,roughness:.16,metalness:.15,clearcoat:1,clearcoatRoughness:.08,envMap}));badge.position.set(b.x,b.y,77);badge.rotation.z=Math.PI;scene.add(badge);
    for(const dx of [-13,13]){const screw=new THREE.Mesh(new THREE.SphereBufferGeometry(2.5,8,6),chrome);screw.scale.z=.4;screw.position.set(b.x+dx,b.y+21,76);scene.add(screw);}
    bumperMechanisms[b.name]={ring,skirt,cap,badge};
  }
  /*const trail=extrude([{x:260,y:70},{x:345,y:70},{x:505,y:340},{x:350,y:550},{x:410,y:790},{x:300,y:850},{x:250,y:590},{x:390,y:335}],1,0xa87c4c);
  trail.position.z=1; scene.add(trail);*/
  for (const z of state.boostZones) {
    const pad=new THREE.Mesh(new THREE.CircleBufferGeometry(z.radius,32),new THREE.MeshBasicMaterial({color:0x00e4ce,transparent:true,opacity:.28}));
    pad.position.set(z.x,z.y,3); scene.add(pad);
    const border=new THREE.Mesh(new THREE.TorusBufferGeometry(z.radius-8,2.5,8,48),glow(0x00ffe2));border.position.set(z.x,z.y,3);scene.add(border);
    const labelCanvas=document.createElement('canvas');labelCanvas.width=256;labelCanvas.height=64;const lc=labelCanvas.getContext('2d');lc.fillStyle='#091a21';lc.fillRect(0,0,256,64);lc.strokeStyle='#26ffe6';lc.lineWidth=5;lc.strokeRect(3,3,250,58);lc.font='bold 34px sans-serif';lc.textAlign='center';lc.fillStyle='#c5fff3';lc.fillText('BOOST',128,45);
    const label=new THREE.Mesh(new THREE.PlaneBufferGeometry(62,16),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(labelCanvas),transparent:true}));label.position.set(z.x,z.y+30,5);label.rotation.z=Math.PI;scene.add(label);
    for(let i=0;i<3;i++) {
      const arrow=extrude([{x:-12,y:9},{x:0,y:-7},{x:12,y:9},{x:12,y:14},{x:0,y:-1},{x:-12,y:14}],2,0xffee62);
      arrow.position.set(z.x,z.y-25+i*17,4);arrow.material=glow(0xffed68);scene.add(arrow);
    }
  }
  for(const [x,y] of [[45,130],[540,180],[60,380],[540,510],[65,610]]) {
    const trunk=new THREE.Mesh(new THREE.CylinderBufferGeometry(7,9,45,8),material(0x795539));
    trunk.rotation.x=Math.PI/2;trunk.position.set(x,y,23);scene.add(trunk);
    const leaves=new THREE.Mesh(new THREE.ConeBufferGeometry(23,65,12),material(0x1c713e));
    leaves.rotation.x=Math.PI/2;leaves.position.set(x,y,88);leaves.castShadow=true;scene.add(leaves);
    for(let i=0;i<3;i++){const tier=new THREE.Mesh(new THREE.ConeBufferGeometry(31-i*5,42,12),material(i%2?0x183f32:0x255541,0));tier.rotation.x=Math.PI/2;tier.position.set(x,y,48+i*19);tier.castShadow=true;scene.add(tier);}
  }
  for (const f of state.flippers) {
    // Rendering only: convex tapered capsule matching VPX's radii and length.
    const points = [];
    const a = Math.asin((f.baseRadius-f.endRadius)/f.length);
    for (let i=0; i<=24; i++) { const t = a + (Math.PI-2*a)*i/24; points.push({x:Math.cos(t)*f.baseRadius,y:Math.sin(t)*f.baseRadius}); }
    for (let i=0; i<=24; i++) { const t = Math.PI-a + (Math.PI+2*a)*i/24; points.push({x:Math.cos(t)*f.endRadius,y:-f.length+Math.sin(t)*f.endRadius}); }
    const mesh = extrude(points, f.height, f.name.includes('Left') ? 0xff36b7 : 0xffdb36);
    const trim=extrude(points,f.height+2,0x2c123d);trim.scale.set(1.12,1.03,1);mesh.add(trim);trim.position.z=-4;
    const inset=extrude(points,3,f.name.includes('Left')?0xff65d5:0xfff08a);inset.scale.set(.75,.92,1);inset.position.z=f.height+3;mesh.add(inset);
    mesh.position.set(f.x, f.y, 0); mesh.rotation.z=f.angle; scene.add(mesh); flipperMeshes[f.name] = mesh;
    const pivot = new THREE.Mesh(new THREE.CylinderBufferGeometry(9,9,54,16),material(0xeefaff,.8)); pivot.rotation.x=Math.PI/2; pivot.position.set(f.x,f.y,27); scene.add(pivot);
  }
  ballMesh = new THREE.Mesh(new THREE.SphereBufferGeometry(state.ballRadius,24,16),material(0xffffff,1)); ballMesh.visible=false; scene.add(ballMesh);
  const spot = new THREE.PointLight(0x38d9ca, .65, 1300); spot.position.set(300,300,180); scene.add(spot);
  const resize = () => {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    renderer.setSize(w,h,false); camera.aspect=w/h;
    const viewH=Math.max(1300,760/camera.aspect),viewW=viewH*camera.aspect;
    camera.left=-viewW/2;camera.right=viewW/2;camera.top=viewH/2;camera.bottom=-viewH/2;
    camera.position.set(300,1220,2400);camera.lookAt(300,550,0);camera.updateProjectionMatrix();
  };
  new ResizeObserver(resize).observe(canvas); resize();
}
function render(time) {
  requestAnimationFrame(render);
  if (!renderer || !latest) return;
  if(introStart!==null){
    const t=Math.min(1,Math.max(0,(time-introStart)/2400)),e=t*t*(3-2*t);
    camera.zoom=.62+.38*e;
    camera.position.set(300,1850-630*e,1550+850*e);camera.lookAt(300,550,0);camera.updateProjectionMatrix();
    if(t>=1)finishIntro();
  }
  if (ready && !framePending) { framePending=true; worker.postMessage({ type: 'frame' }); }
  if(springMesh){springMesh.scale.y=charging ? 1-Math.min(1,(performance.now()-chargeStart)/1100)*.35 : 1;springMesh.position.y=1085*(1-springMesh.scale.y);}
  $('power').style.width=charging?`${Math.min(100,(performance.now()-chargeStart)/11)}%`:'0%';
  ballMesh.visible=!!latest.ball;
  if (latest.ball) ballMesh.position.set(latest.ball._x ?? latest.ball.x,latest.ball._y ?? latest.ball.y,latest.ball._z ?? latest.ball.z);
  if(arcadeMeshes.Kickback){const active=latest.mode==='arcade'&&latest.kickbacks>0;arcadeMeshes.Kickback.material.color.setHex(latest.kickbackUntil>latest.time?0xffffff:active?0x00dfff:0x263c43);}
  for (const f of latest.flippers) flipperMeshes[f.name].rotation.z=f.angle;
  for(const [name,mesh] of Object.entries(arcadeMeshes)) {
    if(name==='Kickback')continue;
    const lit=(latest.flashes[name]||0)>latest.time || latest.targets.includes(name);
    mesh.material.emissive.setHex(lit?0x99772a:0x000000);if(mesh.userData.slingFace)mesh.userData.slingFace.material.emissiveIntensity=lit?1.8:.75;if(name.endsWith('Guide')){const elapsed=250-((latest.flashes[name]||0)-latest.time);mesh.position.z=lit?-4*Math.exp(-elapsed/100)*Math.max(0,Math.sin(elapsed/22)):0;}
  }
  for(const [name,m] of Object.entries(bumperMechanisms)) {
    const remaining=(latest.flashes[name]||0)-latest.time;
    const elapsed=250-remaining;
    const compression=remaining>0?Math.exp(-elapsed/85)*Math.sin(Math.PI*elapsed/65):0;
    m.ring.position.z=36-9*Math.max(0,compression);
    m.skirt.rotation.z=compression*.08;m.cap.position.z=69-2*Math.max(0,compression);m.badge.position.z=77-2*Math.max(0,compression);
  }
  for(const [name,inserts] of Object.entries(insertGroups)){
    const active=latest.rampLights[name]>latest.time || (latest.comboUntil>latest.time&&name!==latest.lastRamp);
    inserts.forEach((m,i)=>{m.material.opacity=active?(Math.floor(latest.time/110)%inserts.length===i?1:.35):.3;});
  }
  leaderboard.update(latest);
  const digits=String(latest.score).padStart(7,'0');
  if($('score').dataset.value!==digits){
    const segments=['abcdef','bc','abdeg','abcdg','bcfg','acdfg','acdefg','abc','abcdefg','abcdfg'];
    $('score').innerHTML=[...digits].map(d=>`<span class="digit" aria-hidden="true">${[...'abcdefg'].map(k=>`<i class="seg ${k} ${segments[+d].includes(k)?'on':''}"></i>`).join('')}</span>`).join('');
    $('score').dataset.value=digits;$('score').setAttribute('aria-label',`${latest.score} points`);
  }
  $('multiplier').textContent=`×${latest.multiplier}`;
  $('mission').textContent=`${latest.mission} · ${latest.progress}/${latest.goal} · Rang ${latest.rank}`;
  $('event').textContent=latest.staged ? 'Maintiens le lanceur ou Espace, puis relâche' : latest.time<latest.saveUntil&&!latest.saved ? 'Protection de bille active · 7 secondes au départ' : latest.event;
  audio.event(latest);effects.update(latest,paused);
  if(lastMode!==latest.mode){lastMode=latest.mode;bestScore=records[lastMode]||0;}
  $('mode').textContent=latest.mode==='classic'?'Mode : Classique':'Mode : Arcade';
  $('tilt').textContent=latest.tilted?'TILT':`TILT ${'●'.repeat(latest.nudgeWarnings)}${'○'.repeat(3-latest.nudgeWarnings)}`;
  $('target-bank').textContent=`TRAIL ${[0,1,2].map(i=>latest.targetDropped.includes(`Target${i}`)?'●':'○').join(' ')}`;
  if(latest.score>bestScore){bestScore=latest.score;try{records[lastMode]=bestScore;localStorage.setItem(lastMode==='classic'?'forest-cadet-best-classic':'forest-cadet-best',String(bestScore));}catch{}}
  $('best').textContent=`RECORD ${bestScore.toLocaleString('fr-FR')}`;
  $('balls').textContent=latest.gameOver?'FIN DE PARTIE':`BILLE ${latest.ballNumber} / 3`;
  const comboActive=latest.comboUntil>latest.time;
  $('combo').textContent=comboActive?`COMBO ×${latest.combo} · ${Math.ceil((latest.comboUntil-latest.time)/1000)} s`:`JACKPOTS ${latest.jackpots}`;
  $('progress').max=latest.goal;$('progress').value=latest.progress;
  $('shot').textContent=latest.tilted?'TILT · commandes bloquées jusqu’à la prochaine bille':latest.gameOver?'Expédition terminée · lancez une nouvelle partie':latest.staged?'Chargez le lanceur · cible rapide pour le skill shot':latest.skillAvailable&&latest.time<latest.skillUntil?`SKILL SHOT · touchez une cible · ${Math.ceil((latest.skillUntil-latest.time)/1000)} s`:comboActive?`Prochain tir : ${latest.lastRamp==='LeftRamp'?'cascade droite':'crête gauche'}${latest.combo===2?' · JACKPOT':''}`:`${latest.mission} : ${latest.goal-latest.progress} impacts · ou visez une rampe`;
  if(lastAnnouncement!==latest.eventId){lastAnnouncement=latest.eventId;$('event').classList.remove('flash');requestAnimationFrame(()=>$('event').classList.add('flash'));}
  start.disabled=!!latest.ball&&!latest.staged;
  if(!charging)$('launch-label').textContent=latest.gameOver?'Nouvelle partie':latest.staged?'Tirer / relâcher':'Bille en piste';
  for(const name of ['Target0','Target1','Target2']){const m=arcadeMeshes[name];const z=latest.targetDropped.includes(name)?-85:0;m.position.z+=(z-m.position.z)*.2;}
  if(!latest.combo)lastCelebration='';
  if(latest.combo>=3&&latest.comboUntil>latest.time){const id=`${latest.rampPasses}:${latest.combo}`;if(lastCelebration!==id){lastCelebration=id;const title=latest.combo===3?'YETI JACKPOT !':`YETI COMBO ×${latest.combo} !`;$('celebration-title').textContent=title;$('celebration-score').textContent=latest.event;$('celebration').classList.remove('show');void $('celebration').offsetWidth;$('celebration').classList.add('show');}}
  renderer.render(scene,camera); frameCount++;
  if (time-fpsStart>1000) { fps=Math.round(frameCount*1000/(time-fpsStart)); frameCount=0; fpsStart=time; debug.fps=fps; }
  ballMesh.material.emissive.setHex(latest.time < latest.boostUntil ? 0xffb000 : 0x000000);
  status.textContent = `${latest.gameOver?'FIN DE PARTIE':paused ? 'PAUSE' : latest.staged ? 'PRÊT À LANCER' : latest.ball ? 'EN PISTE' : 'NOUVELLE BILLE'} · FOREST CADET`;
}
async function boot() {
  try {
    worker = new Worker('./physics.worker.js');
    worker.onerror = e => fail(e.message);
    worker.onmessage = ({data}) => {
      try {
      if (data.type === 'error') return fail(data.error);
      if (data.state) { latest={...data.state,ramps:data.state.ramps || latest?.ramps}; debug.state=latest; framePending=false; }
      if (data.type === 'ready') {
        initScene(latest); ready=true; debug.ready=true; start.disabled=false; pauseButton.disabled=false;
        $('loading').hidden=true;if(!reducedMotion.matches){introStart=performance.now();document.body.classList.add('cabinet-arrival');}requestAnimationFrame(render);
      }
      if (data.type === 'drain') $('launch-label').textContent='Nouvelle bille';
      } catch (error) { fail(error); }
    };
    const response=await fetch('./mtb-test.vpx'); if (!response.ok) throw new Error(`Plateau : HTTP ${response.status}`);
    worker.postMessage({ type:'init', blob:await response.blob() });
  } catch(error) { fail(error); }
}
boot();
$('replay-intro').addEventListener('click',()=>{if(!ready||reducedMotion.matches)return;setPaused();introStart=performance.now();document.body.classList.add('cabinet-arrival');});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{$('fullscreen').textContent='Plein écran indisponible';}});
