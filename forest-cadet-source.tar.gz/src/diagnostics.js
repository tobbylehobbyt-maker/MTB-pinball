// SPDX-License-Identifier: GPL-2.0-or-later
import { createEngine } from './engine.js';
import { bindInputs } from './input.js';
const $=id=>document.getElementById(id);
let report={environment:{ua:navigator.userAgent,width:innerWidth,height:innerHeight,pixelRatio:devicePixelRatio,secureContext:isSecureContext,pointerEvents:typeof PointerEvent!=='undefined',workers:typeof Worker!=='undefined',multitouch:navigator.maxTouchPoints},results:[]};
const assert=(value,message)=>{if(!value)throw Error(message);};
const step=(e,end,begin=0)=>{for(let t=begin;t<=end;t+=5)e.player.updatePhysics(t);};
function show(){ $('output').textContent=JSON.stringify(report,null,2); }
bindInputs({left:$('left'),right:$('right'),send:(side,down)=>{$('touch').textContent=`${side} ${down?'enfoncé':'relâché'} — observez les deux boutons allumés avec deux doigts.`;},launch(){},pause(){}});
async function check(name,run) {try{await run();report.results.push({name,pass:true});}catch(error){report.results.push({name,pass:false,error:error.message});}show();}
$('run').onclick=async()=> {
  $('run').disabled=true;report.results=[];const response=await fetch('./mtb-test.vpx');const blob=await response.blob();
  const fresh=()=>createEngine(blob);
  await check('WebGL context',()=>{const c=document.createElement('canvas');const gl=c.getContext('webgl');assert(gl,'WebGL indisponible');gl.getExtension('WEBGL_lose_context')?.loseContext();});
  await check('VPX: two flippers, two guides',async()=>{const e=await fresh();assert(Object.keys(e.table.flippers).length===2,'Batteurs absents');assert(Object.keys(e.table.surfaces).length===2,'Guides absents');});
  await check('VPX gravity and playfield',async()=>{const e=await fresh();const b=e.spawn(300,300,0,0);step(e,500);assert(b.getState().pos.y>300&&Math.abs(b.getState().pos.z-25)<1,'Gravité incorrecte');});
  await check('VPX real wall rebound',async()=>{const e=await fresh();const b=e.spawn(540,300,12,0);step(e,100);assert(b.hit.vel.x<0,'Rebond absent');});
  await check('VPX guide rebound',async()=>{const e=await fresh();const b=e.spawn(160,810,-10,0);step(e,100);assert(b.hit.vel.x>0&&b.getState().pos.x>100,'Guide incorrect');});
  for(const [side,x]of [['left',185],['right',415]])await check(`VPX ${side} flipper hits ball`,async()=>{const e=await fresh();const b=e.spawn(x,910,0,0);step(e,20);e.flip(side,true);step(e,150,25);assert(b.hit.vel.y<0&&b.getState().pos.y<900,'Impulsion absente');});
  await check('Compiled worker: VPX load, ball, both flippers',()=>new Promise((resolve,reject)=>{
    const w=new Worker('./physics.worker.js');let phase=0;const limit=setTimeout(()=>{w.terminate();reject(Error('Worker timeout'));},5000);
    const end=error=>{clearTimeout(limit);w.terminate();error?reject(error):resolve();};
    w.onerror=e=>end(Error(e.message));w.onmessage=({data})=>{
      if(data.type==='error')return end(Error(data.error));
      if(data.type==='ready'){w.postMessage({type:'launch'});w.postMessage({type:'resume'});w.postMessage({type:'flip',side:'left',down:true});w.postMessage({type:'flip',side:'right',down:true});phase=1;setTimeout(()=>w.postMessage({type:'frame'}),180);}
      else if(data.type==='state'&&phase===1&&data.state.time>100){try{assert(data.state.ball,'Pas de bille');assert(Math.abs(data.state.flippers[0].angle*180/Math.PI-70)<1&&Math.abs(data.state.flippers[1].angle*180/Math.PI-290)<1,'Batteurs incorrects');end();}catch(error){end(error);}}
    };w.postMessage({type:'init',blob});
  }));
  report.date=new Date().toISOString();$('run').disabled=false;show();
};
$('save').onclick=()=>{const a=document.createElement('a');const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));a.href=url;a.download='mtb-safari-diagnostic.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};show();
