// SPDX-License-Identifier: GPL-2.0-or-later
import { RampMeshGenerator } from '../vendor/vpx-js/lib/vpt/ramp/ramp-mesh-generator';
import { HIT_SHAPE_DETAIL_LEVEL } from '../vendor/vpx-js/lib/physics/constants';
import { tubeLoop,pointOnTube } from './tube-loop.js';
import { createArcade } from './arcade.js';
import { Table } from '../vendor/vpx-js/lib/vpt/table/table';
import { Player } from '../vendor/vpx-js/lib/game/player';
import { Vertex3D } from '../vendor/vpx-js/lib/math/vertex3d';
import { BrowserBinaryReader } from '../vendor/vpx-js/lib/io/binary-reader.browser';
import { Logger, Progress } from '../vendor/vpx-js/lib/util/logger';
// Quiet diagnostics; errors remain visible. No replacement physics implementation.
Logger.setLogger({ info() {}, verbose() {}, debug() {}, warn() {}, error: console.error, wtf: console.error });
Progress.setProgress({ start() {}, end() {}, show() {}, details() {} });
// Arcade returns aim inward with a small symmetric variation; this is not a side quota.
export function centerReturnVelocity(x,random=Math.random){return Math.max(-7,Math.min(7,(300-x)*.035))+(random()-.5)*2;}
export const BALL_RADIUS=12.5;
export async function createEngine(blob) {
  const table = await Table.load(new BrowserBinaryReader(blob), { loadInvisibleItems: true, loadTableScript: false });
  if (!table.flippers.LeftFlipper || !table.flippers.RightFlipper) throw new Error('Le plateau MTB doit contenir LeftFlipper et RightFlipper.');
  // Visual Pinball recommended material values; scatter is radians inside VPX-JS.
  table.data.globalDifficulty=.15;
  table.data.elasticity=.25;
  const player = new Player(table).init();
  const scatter=5*Math.PI/180;
  for(const ramp of Object.values(table.ramps))for(const hit of ramp.getHitShapes()){
    const floor=hit.constructor.name==='HitTriangle';
    // Narrow elevated tracks retain their validated guide response.
    hit.elasticity=floor?.02:.8;hit.friction=.01;hit.scatter=0;
  }
  for(const bumper of Object.values(table.bumpers))for(const hit of bumper.getHitShapes()){
    hit.elasticity=.8;hit.elasticityFalloff=.4;hit.friction=.55;hit.scatter=scatter;
  }
  for(const surface of Object.values(table.surfaces)){
    const name=surface.getName(),rubber=['LeftGuide','RightGuide'].includes(name)||name.startsWith('Rock');
    const wood=name.includes('WoodGuide'),target=name.startsWith('Target'),rail=name.includes('Divider');
    for(const hit of surface.getHitShapes()){
      hit.elasticity=rubber?.8:wood?.4:target?.375:rail?.425:.3;
      hit.elasticityFalloff=rubber?.4:0;
      hit.friction=rubber?.55:wood?.25:rail?.15:.2;
      hit.scatter=scatter;
    }
  }
  const width = table.data.right - table.data.left, height = table.data.bottom - table.data.top;
  const arcade=createArcade();
  let mode='arcade';
  let kickbacks=2,kickbackUntil=0,kickbackReadyAt=0;
  let crossTrailPending=false,crossTrailReadyAt=0;
  let targetDropped=new Set(),targetResetAt=0;
  const resetTargets=()=>{targetDropped.clear();targetResetAt=0;for(const t of Object.values(table.surfaces).filter(t=>t.getName().startsWith('Target')))t.getApi().Collidable=true;};
  let ballNumber=1,gameOver=false,tilted=false,nudgeTimes=[],lastNudge=-Infinity;
  let collisions = 0, boosts = 0, boostUntil = 0, saveUntil=0, saved=false, staged=false;
  const boostZones = [{x:140,y:490,radius:58},{x:435,y:640,radius:58}];
  const rampMeshes=Object.values(table.ramps).map(r=>{
    const gen=new RampMeshGenerator(r.data,r.getState());
    const rv=gen.getRampVertex(table,HIT_SHAPE_DETAIL_LEVEL,true),n=rv.pcvertex;
    return {name:r.getName(),width:r.data.widthBottom,wallHeight:r.data.leftWallHeight,
      left:Array.from({length:n},(_,i)=>({x:rv.rgvLocal[2*n-i-1].x,y:rv.rgvLocal[2*n-i-1].y,z:rv.ppheight[i]})),
      right:Array.from({length:n},(_,i)=>({x:rv.rgvLocal[i].x,y:rv.rgvLocal[i].y,z:rv.ppheight[i]}))};
  });
  const tubeLoops=rampMeshes.map(tubeLoop);
  let tubeRide=null,tubeReadyAt=0;
  let insideBoost = false, rampPasses=0;
  let stuckAnchor=null,stuckSince=0,stuckAttempts=0,ballRecoveries=0,stuckSamples=[],lastStuckSample=-Infinity;
  let rampProgress={LeftRamp:-1,RightRamp:-1},rampLights={LeftRamp:0,RightRamp:0};
  const updateRampSensors=(p,time)=>{
    if(tilted)return;
    for(const r of rampMeshes){
      let nearest=0,distance=Infinity;
      for(let i=0;i<r.left.length;i++){const a=r.left[i],b=r.right[i],d=Math.hypot(p.x-(a.x+b.x)/2,p.y-(a.y+b.y)/2,p.z-(a.z+BALL_RADIUS));if(d<distance){distance=d;nearest=i;}}
      const n=r.left.length;
      if(distance<r.width*.43){
        if(nearest<6 && rampProgress[r.name]<0){rampProgress[r.name]=0;rampLights[r.name]=time+12000;}
        if(rampProgress[r.name]>=0 && nearest>=rampProgress[r.name] && nearest-rampProgress[r.name]<20)rampProgress[r.name]=nearest;
        if(nearest>n-5 && rampProgress[r.name]>n*.8){rampPasses++;arcade.ramp(r.name,time);rampProgress[r.name]=-1;rampLights[r.name]=time+1800;}
      }
      if(rampProgress[r.name]>=0 && ((nearest<3 && rampProgress[r.name]>8)||time>rampLights[r.name]))rampProgress[r.name]=-1;
    }
  };
  const protectStuckBall=(ball,time)=>{
    const p=ball.getState().pos;
    if(isDraining()){stuckSamples=[];stuckAnchor=null;return;}
    // Require sustained confinement, rather than a low velocity at a single instant.
    if(stuckAnchor&&Math.hypot(p.x-stuckAnchor.x,p.y-stuckAnchor.y,p.z-stuckAnchor.z)>100){stuckAttempts=0;stuckAnchor=null;}
    if(time-lastStuckSample<100)return;lastStuckSample=time;
    stuckSamples.push({x:p.x,y:p.y,z:p.z,time});
    stuckSamples=stuckSamples.filter(s=>time-s.time<=3200);
    if(stuckSamples.length<2||time-stuckSamples[0].time<3000)return;
    const extent=axis=>Math.max(...stuckSamples.map(s=>s[axis]))-Math.min(...stuckSamples.map(s=>s[axis]));
    if(extent('x')>35||extent('y')>35||extent('z')>24)return;
    stuckSamples=[];stuckSince=time;
    const v=ball.hit.vel;
    if(tilted){p.set(300,1060,BALL_RADIUS);return;}
    if(stuckAttempts<2){
      if(!stuckAnchor)stuckAnchor={x:p.x,y:p.y,z:p.z};stuckAttempts++;
      // A small lift clears the top lip of a flat obstacle or flipper before the sideways push.
      v.x=(p.x<300?1:-1)*(stuckAttempts===1?5:8);v.y=-7;v.z=Math.max(v.z,2.5);
      arcade.announce('Bille bloquée · dégagement automatique');return;
    }
    p.set(575,985,BALL_RADIUS);v.set(0,-50,0);stuckAnchor=null;stuckAttempts=0;stuckSamples=[];insideBoost=false;rampProgress={LeftRamp:-1,RightRamp:-1};ballRecoveries++;arcade.announce('Bille récupérée · relance sans perte de bille');
  };
  const updateRules = () => {
    if(targetResetAt&&player.getGameTime()>=targetResetAt){const p=player.balls[0]?.getState().pos;if(!p||p.x<40||p.x>230||p.y<55||p.y>160)resetTargets();}
    const ball=player.balls[0]; if (!ball) return;
    if(staged){ball.getState().pos.set(575,985,BALL_RADIUS);ball.hit.vel.set(0,0,0);return;}
    const p=ball.getState().pos, time=player.getGameTime();
    if(tilted&&tubeRide){tubeRide=null;tubeReadyAt=time+3000;ball.hit.vel.set(0,4,0);}
    if(mode==='arcade'&&!tilted){
      if(!tubeRide&&time>=tubeReadyAt){
        const loop=tubeLoops.find(r=>Math.hypot(p.x-r.points[0].x,p.y-r.points[0].y,p.z-r.points[0].z)<38);
        if(loop){tubeRide={name:loop.name,distance:0,speed:.65,lastTime:time};rampProgress[loop.name]=-1;arcade.announce('TURBO TUBE · aspiration !');}
      }
      if(tubeRide){
        const loop=tubeLoops.find(r=>r.name===tubeRide.name),dt=Math.min(50,Math.max(0,time-tubeRide.lastTime));tubeRide.lastTime=time;
        tubeRide.speed=Math.min(1.35,tubeRide.speed+dt*.00035);tubeRide.distance+=tubeRide.speed*dt;
        const q=pointOnTube(loop,tubeRide.distance);p.set(q.x,q.y,q.z);ball.hit.vel.set(0,0,0);stuckSamples=[];
        if(tubeRide.distance>=loop.length){
          rampPasses++;arcade.ramp(loop.name,time);rampLights[loop.name]=time+1800;
          ball.hit.vel.set(centerReturnVelocity(p.x),-18,0);tubeRide=null;tubeReadyAt=time+3000;
        }
        return;
      }
    }
    // A limited physical kickback lifts the ball out of the left outlane.
    if(mode==='arcade'&&!tilted&&kickbacks>0&&time>=kickbackReadyAt&&p.x<65&&p.y>845&&p.y<965&&p.z<45&&ball.hit.vel.y>0){
      kickbacks--;kickbackUntil=time+1200;kickbackReadyAt=time+1800;
      ball.hit.vel.set(2+Math.random()*2,-(29+Math.random()*4),1);
      arcade.announce(`KICKBACK · sauvetage gauche ! ${kickbacks} restant${kickbacks>1?'s':''}`);
    }
    // Apply after the collision solver, so its reflection cannot undo this arcade kicker.
    if(crossTrailPending){
      crossTrailPending=false;
      if(mode==='arcade'&&!tilted&&p.y<760&&p.z<55&&time>=crossTrailReadyAt){
        ball.hit.vel.x=centerReturnVelocity(p.x);
        ball.hit.vel.y=-Math.max(6,Math.min(16,Math.abs(ball.hit.vel.y)));
        crossTrailReadyAt=time+900;
      }
    }
    protectStuckBall(ball,time);
    updateRampSensors(p,time);
    const inside=!tilted && p.z<45 && boostZones.some(z=>Math.hypot(p.x-z.x,p.y-z.y)<z.radius);
    if (inside && !insideBoost && time>=boostUntil) {
      if(mode==='arcade'){ball.hit.vel.y=-24;ball.hit.vel.x=centerReturnVelocity(p.x);}
      boosts++; arcade.hit('Boost',time); boostUntil=time+900;
    }
    insideBoost=inside;
  };
  for (const item of table.getHittables()) {
    const api = item.getApi?.();
    let lastImpact = -Infinity;
    const countImpact = () => { const time = player.getGameTime();if(targetDropped.has(item.getName()))return; if (!tilted && time - lastImpact >= 100) { collisions++; arcade.hit(item.getName(),time);if(mode==='arcade'&&(item.getName().startsWith('Rock')||item.getName().startsWith('Bumper')||['LeftGuide','RightGuide'].includes(item.getName())))crossTrailPending=true;lastImpact=time;if(item.getName().startsWith('Target')){targetDropped.add(item.getName());api.Collidable=false;if(targetDropped.size===3)targetResetAt=time+1200;} } };
    if (api) { api.on('Hit', countImpact); api.on('Collide', countImpact);api.on('Slingshot',countImpact); }
  }
  const spawn = (x = 500, y = 650, vx = -5, vy = -18) => {
    tubeRide=null;tubeReadyAt=player.getGameTime()+200;crossTrailPending=false;crossTrailReadyAt=0;stuckAnchor=null;stuckAttempts=0;stuckSamples=[];lastStuckSample=-Infinity;rampProgress={LeftRamp:-1,RightRamp:-1};staged=false; insideBoost=false; boostUntil=0; saveUntil=player.getGameTime()+7000; saved=false;
    for (const b of [...player.balls]) player.destroyBall(b);
    return player.createBall({
      getBallCreationPosition: () => new Vertex3D(x, y, table.data.tableHeight),
      getBallCreationVelocity: () => new Vertex3D(vx, vy, 0), onBallCreated() {},
    },BALL_RADIUS);
  };
  const flip = (side, down) => {
    if(tilted&&down)return;
    for(const name of side==='left'?['LeftFlipper','UpperLeftFlipper']:['RightFlipper','UpperRightFlipper']){
      const api=table.flippers[name]?.getApi();if(api)down?api.RotateToEnd():api.RotateToStart();
    }
  };
  const snapshot = () => ({
    ballRadius:BALL_RADIUS,time: player.getGameTime(), tubeRide:tubeRide?{...tubeRide}:null,kickbacks,kickbackUntil,ballNumber,gameOver,tilted,mode,targetDropped:[...targetDropped],targetResetAt,ballRecoveries,nudgeWarnings:tilted?3:nudgeTimes.filter(t=>player.getGameTime()-t<5000).length,collisions, ...arcade.snapshot(), ramps:rampMeshes,rampPasses,rampLights,saveUntil, saved, staged, boosts, boostUntil, boostZones, width, height,
    ball: player.balls[0] ? { x: player.balls[0].getState().pos.x, y: player.balls[0].getState().pos.y, z: player.balls[0].getState().pos.z } : null,
    bumpers: Object.values(table.bumpers).map(b=>({name:b.getName(),x:b.data.center.x,y:b.data.center.y,radius:b.data.radius})),
    flippers: Object.values(table.flippers).map(f => ({ name: f.getName(), angle: f.getState().angle, x: f.data.center.x, y: f.data.center.y, length: f.data.flipperRadius, baseRadius: f.data.baseRadius, endRadius: f.data.endRadius, height: f.data.height })),
    walls: Object.values(table.surfaces).map(w => ({ name: w.getName(), height: w.data.heightTop, points: w.data.dragPoints.map(p => ({ x: p.vertex.x, y: p.vertex.y })) })),
  });
  const stage=()=>{kickbacks=2;kickbackUntil=0;kickbackReadyAt=0;resetTargets();arcade.clearTargets();spawn(575,985,0,0);staged=true;};
  const fire=(power=1)=>{if(!staged)stage();staged=false;tilted=false;nudgeTimes=[];arcade.beginBall(player.getGameTime());saveUntil=player.getGameTime()+7000;player.balls[0].hit.vel.set(0,-(38+Math.max(0,Math.min(1,power))*17),0);};
  const drain=()=>{
    const b=player.balls[0];
    if(b && !tilted && !saved && player.getGameTime()<saveUntil) {
      b.getState().pos.set(575,985,BALL_RADIUS);b.hit.vel.set(0,-50,0);saved=true;arcade.announce('Bille sauvée · repartez sur le trail !');return false;
    }
    if(b){player.destroyBall(b);if(!tilted)arcade.endBall();if(ballNumber>=3){gameOver=true;arcade.announce('Expédition terminée · Nouvelle partie pour repartir');}else ballNumber++;}return true;
  };
  const isDraining=()=>{if(tubeRide)return false;const p=player.balls[0]?.getState().pos;return !!p&&!staged&&((p.y>980&&(p.x<72||(p.x>484&&p.x<537)))||p.y>1040);};
  const nudge=(direction='up')=>{const b=player.balls[0],time=player.getGameTime();if(!b||staged||tilted||time-lastNudge<500)return;lastNudge=time;nudgeTimes=nudgeTimes.filter(t=>time-t<5000);nudgeTimes.push(time);if(nudgeTimes.length>=3){tilted=true;flip("left",false);flip("right",false);arcade.announce("TILT · batteurs coupés jusqu’à la prochaine bille");return;}b.hit.vel.y-=direction==='up'?4:2.5;if(direction==='left')b.hit.vel.x-=3;if(direction==='right')b.hit.vel.x+=3;arcade.announce(`Secousse · avertissement ${nudgeTimes.length}/2`);};
  const newGame=()=>{tilted=false;nudgeTimes=[];lastNudge=-Infinity;arcade.reset();ballNumber=1;gameOver=false;collisions=0;boosts=0;rampPasses=0;ballRecoveries=0;stage();};
  const setMode=value=>{if(!['arcade','classic'].includes(value))return false;mode=value;newGame();return true;};
  return {setMode,nudge,newGame,isDraining, table, player, spawn, flip, snapshot, updateRules, drain, stage, fire };
}
