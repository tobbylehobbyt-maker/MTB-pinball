// SPDX-License-Identifier: GPL-2.0-or-later
export function createArcade() {
  let score=0, multiplier=1, rank=0, progress=0, eventId=0, event='Bienvenue sur Forest Cadet';
  let targets=new Set(), flashes={},combo=0,comboUntil=0,lastRamp='',jackpots=0,skillUntil=0,skillAvailable=false,bonus=0;
  const reset=()=>{score=0;multiplier=1;rank=0;progress=0;targets.clear();flashes={};combo=0;comboUntil=0;lastRamp='';jackpots=0;bonus=0;skillAvailable=false;announce('Nouvelle expédition · 3 billes');};
  const beginBall=time=>{combo=0;comboUntil=0;lastRamp='';skillUntil=time+8000;skillAvailable=true;bonus=0;};
  const endBall=()=>{const award=bonus*multiplier;score+=award;skillAvailable=false;combo=0;comboUntil=0;lastRamp='';announce(`Bonus de descente · +${award.toLocaleString('fr-FR')}`);multiplier=Math.max(1,multiplier-1);return award;};
  const missions=[{name:'Rock garden',kind:'rock',goal:5},{name:'Flow trail',kind:'boost',goal:3},{name:'Clairière',kind:'bumper',goal:8},{name:'Ascension du sommet',kind:'ramp',goal:2},{name:'Balisage alpin',kind:'target',goal:3},{name:'Descente nocturne',kind:'boost',goal:5}];
  const announce=text=>{event=text;eventId++;};
  const hit=(name,time=0)=>{
    flashes[name]=time+250;
    const kind=name.startsWith('Rock')?'rock':name.startsWith('Bumper')?'bumper':name.startsWith('Target')?'target':name==='Boost'?'boost':'guide';
    score+=({rock:100,bumper:200,target:300,boost:250,guide:10}[kind])*multiplier;
    if(kind!=='guide')bonus+=25;
    if(kind==='target'&&skillAvailable&&time<=skillUntil){skillAvailable=false;score+=2500*multiplier;announce(`SKILL SHOT · +${2500*multiplier}`);}
    if(kind==='target') {
      targets.add(name);
      if(targets.size===3) {multiplier=Math.min(5,multiplier+1);targets.clear();score+=1000;announce(`TRAIL complet · multiplicateur ×${multiplier}`);}
    }
    const m=missions[rank%missions.length];
    if(kind===m.kind && ++progress>=m.goal) {score+=2000*multiplier;rank++;progress=0;announce(`Mission réussie ! +${2000*multiplier} · Rang ${rank+1}`);}
    else if(kind==='boost') announce(`BOOST ! +${250*multiplier}`);
  };
  const ramp=(name,time)=>{
    const chained=time<=comboUntil&&name!==lastRamp;
    combo=chained?Math.min(5,combo+1):1;lastRamp=name;comboUntil=time+15000;
    const award=1500*multiplier*combo;score+=award;bonus+=150;flashes[name]=time+1800;
    if(combo===3){const jackpot=10000*multiplier;score+=jackpot;jackpots++;announce(`SUMMIT JACKPOT · +${jackpot+award}`);}
    else announce(`${combo>1?`COMBO ×${combo} · `:''}${name==='LeftRamp'?'Crête gauche':'Cascade droite'} · +${award}`);
    const mission=missions[rank%missions.length];if(mission.kind==='ramp'&&++progress>=mission.goal){score+=2000*multiplier;rank++;progress=0;announce(`Sommet atteint · +${2000*multiplier} · Rang ${rank+1}`);}
  };
  return {clearTargets:()=>targets.clear(),ramp,hit,announce,reset,beginBall,endBall,snapshot:()=>({score,multiplier,rank:rank+1,mission:missions[rank%missions.length].name,goal:missions[rank%missions.length].goal,progress,targets:[...targets],flashes:{...flashes},event,eventId,combo,comboUntil,lastRamp,jackpots,skillUntil,skillAvailable,bonus})};
}
