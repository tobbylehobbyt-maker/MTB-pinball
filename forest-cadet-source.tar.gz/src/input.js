// SPDX-License-Identifier: GPL-2.0-or-later
// Each pointer/key owns its input. Releasing one finger never releases another.
export class InputState {
  constructor(send) { this.send = send; this.owners = new Map(); }
  press(id, side) {
    if (this.owners.has(id)) return;
    const wasDown = this.down(side); this.owners.set(id, side);
    if (!wasDown) this.send(side, true);
  }
  release(id) {
    const side = this.owners.get(id); if (!side) return;
    this.owners.delete(id); if (!this.down(side)) this.send(side, false);
  }
  down(side) { return [...this.owners.values()].includes(side); }
  clear() { const sides = new Set(this.owners.values()); this.owners.clear(); for (const side of sides) this.send(side, false); }
}
export function bindInputs({ left, right, touchLeft, touchRight, send, launch, charge, release, pause }) {
  const state = new InputState(send);
  const controls=[[left,'left'],[right,'right'],[touchLeft,'left'],[touchRight,'right']].filter(([button])=>button);
  const sync=()=>controls.forEach(([button,side])=>button.classList.toggle('held',state.down(side)));
  for (const [button, side] of controls) {
    button.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      e.preventDefault(); button.setPointerCapture(e.pointerId);
      state.press(`p${e.pointerId}`, side); sync();
    });
    for (const event of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(event, e => {
      state.release(`p${e.pointerId}`); sync();
    });
    button.addEventListener('contextmenu', e => e.preventDefault());
  }
  const keySide = e => e.key.toLowerCase() === 'a' || ['ShiftLeft', 'KeyA', 'ArrowLeft'].includes(e.code) ? 'left' : e.key.toLowerCase() === 'd' || ['ShiftRight', 'KeyD', 'ArrowRight'].includes(e.code) ? 'right' : null;
  window.addEventListener('keydown', e => {
    if(e.target.closest?.('input,select,textarea,dialog[open]')||document.querySelector('dialog[open]'))return;
    const side = keySide(e);
    if (side) { e.preventDefault(); state.press(`k${e.code}`, side); }
    if (e.code === 'Space' && !e.repeat) { e.preventDefault(); charge ? charge() : launch(); }
    if (e.code === 'KeyP' && !e.repeat) pause();
  });
  window.addEventListener('keyup', e => {if(e.target.closest?.('input,select,textarea,dialog[open]')||document.querySelector('dialog[open]'))return;state.release(`k${e.code}`);if(e.code==='Space'){e.preventDefault();release?.();}});
  const clear = () => { state.clear(); sync(); };
  window.addEventListener('blur', clear);
  document.addEventListener('visibilitychange', () => { if (document.hidden) clear(); });
  return { state, clear };
}
