// SPDX-License-Identifier: GPL-2.0-or-later
export function createLeaderboard(onOpen) {
  const $=id=>document.getElementById(id), dialog=$('leaderboard-dialog');
  let config, session, finished=null, previousOver=false, busy=false, request=0;
  const message=text=>{$('leaderboard-status').textContent=text;};
  try{$('player-name').value=localStorage.getItem('forest-cadet-name')||'';session=JSON.parse(localStorage.getItem('forest-cadet-session')||'null');}catch{}
  async function configuration(){
    if(!config){const response=await fetch('./leaderboard-config.json',{cache:'no-cache'});if(!response.ok)throw Error('Configuration indisponible.');config=await response.json();}
    if(!config.url||!config.publishableKey)throw Error('Le classement en ligne sera disponible après sa connexion.');
    const url=new URL(config.url);if(url.protocol!=='https:'||!url.hostname.endsWith('.supabase.co'))throw Error('Configuration du classement invalide.');
    config.url=url.origin;return config;
  }
  async function api(path,body,token){
    await configuration();
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),12000);
    try{
      const response=await fetch(config.url+path,{method:'POST',headers:{apikey:config.publishableKey,'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify(body),signal:controller.signal});
      const raw=await response.text(),data=raw?JSON.parse(raw):null;if(!response.ok)throw Error('Connexion impossible. Réessayez dans un instant.');return data;
    }finally{clearTimeout(timeout);}
  }
  async function identity(){
    if(!session||session.expires_at<Date.now()/1000+60){
      session=session?.refresh_token?await api('/auth/v1/token?grant_type=refresh_token',{refresh_token:session.refresh_token}):await api('/auth/v1/signup',{data:{}});
      session.expires_at=Date.now()/1000+session.expires_in;
      try{localStorage.setItem('forest-cadet-session',JSON.stringify(session));}catch{}
    }
    return session.access_token;
  }
  async function refresh(){
    const current=++request, mode=$('ranking-mode').value;
    $('ranking-list').replaceChildren();message('Chargement du classement…');
    try{
      const rows=await api('/rest/v1/rpc/forest_top_scores',{p_mode:mode});
      if(current!==request)return;
      for(const row of rows){const li=document.createElement('li'),name=document.createElement('span'),score=document.createElement('strong');name.textContent=row.pseudo;score.textContent=Number(row.score).toLocaleString('fr-FR');li.append(name,score);$('ranking-list').append(li);}
      message(rows.length?'Top 20 · meilleurs scores par joueur':'Le trail attend son premier record !');
    }catch(error){if(current===request)message(error.message);}
  }
  $('leaderboard').addEventListener('click',()=>{onOpen();$('ranking-mode').value=finished?.mode||'arcade';dialog.showModal();refresh();});
  $('ranking-close').addEventListener('click',()=>dialog.close());
  $('ranking-mode').addEventListener('change',refresh);
  $('ranking-refresh').addEventListener('click',refresh);
  $('ranking-form').addEventListener('submit',async event=>{
    event.preventDefault();if(busy||!finished)return;
    const pseudo=$('player-name').value.trim();if(!/^[\p{L}\p{N} _.-]{2,20}$/u.test(pseudo)){message('Pseudo : 2 à 20 lettres ou chiffres.');return;}
    busy=true;$('ranking-submit').disabled=true;
    const result=finished;message('Envoi de votre record…');
    try{
      await api('/rest/v1/rpc/forest_submit_score',{p_pseudo:pseudo,p_score:result.score,p_mode:result.mode},await identity());
      try{localStorage.setItem('forest-cadet-name',pseudo);}catch{}
      if(finished===result)finished=null;
      // A completed game is submitted once; the database retains only the best score.
      $('ranking-result').textContent='Record envoyé !';$('ranking-mode').value=result.mode;await refresh();
    }catch(error){message(error.message);}finally{busy=false;$('ranking-submit').disabled=!finished;}
  });
  return {update(state){
    if(state.gameOver&&!previousOver){finished={score:state.score,mode:state.mode};$('ranking-result').textContent=`Partie terminée : ${state.score.toLocaleString('fr-FR')} points · ${state.mode==='classic'?'Classique':'Arcade'}`;$('ranking-submit').disabled=busy||state.score<=0;}
    previousOver=state.gameOver;
  }};
}
