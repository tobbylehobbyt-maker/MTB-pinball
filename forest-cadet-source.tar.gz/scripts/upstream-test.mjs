// SPDX-License-Identifier: GPL-2.0-or-later
import { build } from 'esbuild';
import { options } from './build.mjs';
import Mocha from 'mocha';
import { resolve } from 'node:path';
import { writeFile, readFile } from 'node:fs/promises';
const specs=[
 'game/player.spec.ts','game/pin-input.spec.ts',
 'vpt/flipper/flipper-hit.spec.ts','vpt/flipper/flipper-mover.spec.ts',
 'vpt/surface/surface-hit.spec.ts',
 'vpt/ball/ball-hit.spec.ts','vpt/ball/ball-mover.spec.ts',
];
const imports=['import "../vendor/vpx-js/test/setup.ts";',...specs.map(f=>`import "../vendor/vpx-js/lib/${f}";`)].join('\n');
await writeFile('reports/upstream-entry.js',imports);
const testInterop={name:'typescript-39-test-interop',setup(build){build.onLoad({filter:/\.spec\.ts$/},async({path})=>({contents:(await readFile(path,'utf8')).replace(/import \* as sinonChai from 'sinon-chai'/g,"import sinonChai from 'sinon-chai'"),loader:'ts'}));}};
await build({...options,platform:'node',format:'cjs',entryPoints:['reports/upstream-entry.js'],outfile:'reports/upstream-tests.cjs',sourcemap:false,plugins:[...options.plugins,testInterop]});
const output=resolve('reports/upstream-results.json');
const mocha=new Mocha({timeout:10000,reporter:'spec'});mocha.addFile(resolve('reports/upstream-tests.cjs'));
process.chdir(resolve('vendor/vpx-js'));
await new Promise(resolveRun=>{
 const runner=mocha.run(failures=>{process.exitCode=failures?1:0;resolveRun();});
 runner.on('end',()=>{requireWrite(runner.stats,runner.failures);});
});
function requireWrite(stats,failures){writeFile(output,JSON.stringify({date:new Date().toISOString(),environment:'Node with upstream browser platform adapter',specs,stats,failures},null,2));}
