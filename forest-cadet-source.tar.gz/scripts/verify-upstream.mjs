// SPDX-License-Identifier: GPL-2.0-or-later
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const lock=JSON.parse(await readFile('sources.lock.json','utf8'));
const failures=[];
for(const [path,hash] of Object.entries(lock.sha256)){
 try{const actual=createHash('sha256').update(await readFile(path)).digest('hex');if(actual!==hash)failures.push(path);}
 catch{failures.push(path);}
}
const meta=JSON.parse(await readFile('reports/physics.worker.js.metafile.json','utf8'));
const required=['lib/game/player-physics.ts','lib/vpt/flipper/flipper-hit.ts','lib/vpt/flipper/flipper-mover.ts','lib/vpt/ball/ball-hit.ts','lib/physics/line-seg.ts','lib/physics/hit-quadtree.ts'];
for(const file of required)if(!meta.inputs['vendor/vpx-js/'+file])failures.push('Not bundled: '+file);
const result={date:new Date().toISOString(),pass:failures.length===0,verifiedFiles:Object.keys(lock.sha256).length,requiredPhysicsModules:required,failures};
await writeFile('reports/source-integrity.json',JSON.stringify(result,null,2));console.log(result);
if(failures.length)process.exitCode=1;
