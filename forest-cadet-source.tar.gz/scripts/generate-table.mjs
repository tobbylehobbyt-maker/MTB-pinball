// SPDX-License-Identifier: GPL-2.0-or-later
// Minimal VPX OLE/BIFF container, derived from upstream GPL test table metadata.
import CFB from 'cfb';
import {tracks,sampleTrack,laneDividers,slingshots} from '../src/table/layout.mjs';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const i32 = n => { const b = Buffer.alloc(4); b.writeInt32LE(n); return b; };
const f32 = n => { const b = Buffer.alloc(4); b.writeFloatLE(n); return b; };
const wide = s => { const b = Buffer.from(s, 'utf16le'); return Buffer.concat([i32(b.length), b]); };
const string = s => { const b = Buffer.from(s); return Buffer.concat([i32(b.length), b]); };
const record = (tag, b = Buffer.alloc(0)) => Buffer.concat([i32(4 + b.length), Buffer.from(tag), b]);
const floats = a => Buffer.concat(a.map(f32));
function records(b) {
  const list = [];
  for (let p = 0; p < b.length;) {
    const len = b.readUInt32LE(p), tag = b.toString('ascii', p + 4, p + 8);
    const extra = tag === 'CODE' ? b.readUInt32LE(p + 8) + 4 : 0;
    list.push([tag, b.subarray(p, p + len + 4 + extra)]);
    p += len + 4 + extra;
    if (tag === 'ENDB') break;
  }
  return list;
}
const source = CFB.read(readFileSync(resolve(root, 'vendor/vpx-js/test/fixtures/table-empty.vpx')), { type: 'buffer' });
const base = CFB.find(source, 'GameData').content;
const patch = {
  NAME: wide('MTBTest'), LEFT: f32(0), TOPX: f32(0), RGHT: f32(600), BOTM: f32(1100),
  SEDT: i32(23), SSND: i32(0), SIMG: i32(0), SCOL: i32(0), SFNT: i32(0),
  IMAG: string(''), MASI: i32(0), GAVT: f32(1), SLOP: f32(6), SLPX: f32(6), TBLH: f32(0), GLAS: f32(500),
};
// No table rules/VBS: the host owns launch/drain and calls the real flipper APIs.
const gameData = Buffer.concat(records(base).map(([tag, raw]) => tag === 'CODE'
  ? Buffer.concat([i32(4), Buffer.from('CODE'), i32(0)])
  : patch[tag] ? record(tag, patch[tag]) : raw));
function flipper(name, x, start, end, y=920, length=115, baseRadius=21.5, endRadius=13) {
  const fields = { NAME: wide(name), VCEN: floats([x, y]), BASR: f32(baseRadius), ENDR: f32(endRadius), FLPR: f32(length),
    ANGS: f32(start), ANGE: f32(end), FORC: f32(1), STRG: f32(2200), ELAS: f32(.8), ELFO: f32(.43),
    FRIC: f32(.6), FRTN: f32(.058), RPUP: f32(3), TODA: f32(.75), TDAA: f32(6),
    FHGT: f32(50), RTHF: f32(7), RHGF: f32(19), RWDF: f32(24), FRMN: f32(0), SCTR: f32(0),
    OVRP: i32(0), VSBL: i32(1), ENBL: i32(1), REEN: i32(1), TMON: i32(0), TMIN: i32(100),
    SURF: string(''), MATR: string(''), RUMA: string(''), IMAG: string('') };
  return Buffer.concat([i32(1), ...Object.entries(fields).map(([t, b]) => record(t, b)), record('ENDB')]);
}
function wall(name, points, sling=false, height=80) {
  const fields = { NAME: wide(name), CLDW: i32(1), HTTP: f32(height), HTBT: f32(0), ELAS: f32(.8),
    WFCT: f32(.15), WSCT: f32(0), OVPH: i32(1), HTEV: i32(1), THRS: f32(2), SLGF:f32(18),SLTH:f32(1),SLGA:i32(1), VSBL: i32(1), SVBL: i32(1), TMON: i32(0) };
  return Buffer.concat([i32(0), ...Object.entries(fields).map(([t, b]) => record(t, b)),
    ...[...points].reverse().flatMap(([x, y],i) => [record('DPNT'), record('VCEN', floats([x, y])), record('POSZ', f32(0)),
      record('SMTH', i32(0)), record('SLNG', i32(sling && i===(name==='RightGuide'?2:1) ? 1 : 0)), record('ATEX', i32(1)), record('TEXC', f32(0)), record('ENDB')]), record('ENDB')]);
}
function bumper(name,x,y) {
 const fields={NAME:wide(name),VCEN:floats([x,y]),RADI:f32(32),FORC:f32(12),THRS:f32(.5),BSCT:f32(0),HISC:f32(65),SURF:string(''),HAHE:i32(1),COLI:i32(1)};
 return Buffer.concat([i32(5),...Object.entries(fields).map(([t,b])=>record(t,b)),record('ENDB')]);
}
function ramp(track){
 const fields={NAME:wide(track.id),TYPE:i32(0),HTBT:f32(0),HTTP:f32(0),WDBT:f32(track.width),WDTP:f32(56),WLHL:f32(70),WLHR:f32(70),WVHL:f32(70),WVHR:f32(70),ELAS:f32(.2),RFCT:f32(.035),RSCT:f32(0),CLDR:i32(1),OVPH:i32(1),RVIS:i32(1),REEN:i32(1)};
 return Buffer.concat([i32(12),...Object.entries(fields).map(([t,b])=>record(t,b)),...sampleTrack(track).flatMap(([x,y,z])=>[record('DPNT'),record('VCEN',floats([x,y,z])),record('POSZ',f32(z)),record('SMTH',i32(0)),record('SLNG',i32(0)),record('ATEX',i32(1)),record('TEXC',f32(0)),record('ENDB')]),record('ENDB')]);
}
const cfb = CFB.utils.cfb_new();
const add = (name, data) => CFB.utils.cfb_add(cfb, name, data);
add('GameStg/Version', i32(1060)); add('GameStg/GameData', gameData);
add('GameStg/GameItem0', flipper('LeftFlipper', 150, 121, 70));
add('GameStg/GameItem1', flipper('RightFlipper', 450, 239, 290));
add('GameStg/GameItem2', wall('LeftGuide',slingshots[0].points,true));
add('GameStg/GameItem3', wall('RightGuide',slingshots[1].points,true));
for (const [i,x,y,radius] of [[4,175,280,40],[5,345,450,40],[6,245,570,35]]) {
 const points=Array.from({length:8},(_,j)=>[x+Math.cos(j*Math.PI/4)*radius,y+Math.sin(j*Math.PI/4)*radius]);
 add(`GameStg/GameItem${i}`,wall(`Rock${i}`,points));
}
for(const [i,x,y] of [[7,275,155],[8,390,200],[9,300,320]]) add(`GameStg/GameItem${i}`,bumper(`Bumper${i}`,x,y));
for(let i=0;i<3;i++) add(`GameStg/GameItem${10+i}`,wall(`Target${i}`,[[75+i*45,100],[99+i*45,100],[99+i*45,116],[75+i*45,116]]));
add('GameStg/GameItem13',wall('LaunchLane',[[537,200],[543,200],[543,1030],[537,1030]]));
add('GameStg/GameItem14',wall('LaunchTurn',[[500,0],[600,0],[600,100]]));
tracks.forEach((t,i)=>add(`GameStg/GameItem${15+i}`,ramp(t)));
laneDividers.forEach((d,i)=>add(`GameStg/GameItem${17+i}`,wall(d.name,d.points)));
add('GameStg/GameItem19',flipper('UpperLeftFlipper',105,121,70,430,65,13,8));
add('GameStg/GameItem20',flipper('UpperRightFlipper',480,239,290,300,65,13,8));
add('GameStg/GameItem21',wall('LeftWoodGuide',[[78,675],[84,669],[151,714],[145,726]],false,28));
add('GameStg/GameItem22',wall('RightWoodGuide',[[404,714],[472,669],[478,675],[410,726]],false,28));
add('TableInfo/TableName' , Buffer.from('MTB Pinball 3D Arcade - Test'));
add('TableInfo/AuthorName', Buffer.from('MTB test host; VPX-JS upstream GPL metadata'));
add('TableInfo/TableVersion', Buffer.from('0.1.0'));
writeFileSync(resolve(root, 'public/mtb-test.vpx'), CFB.write(cfb, { type: 'buffer' }));
console.log('public/mtb-test.vpx : quatre batteurs, guides en bois, sans ROM ni assets commerciaux.');
