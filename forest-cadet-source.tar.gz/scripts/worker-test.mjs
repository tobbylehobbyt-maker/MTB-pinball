// SPDX-License-Identifier: GPL-2.0-or-later
// Executes the actual browser worker bundle in a Node VM. This verifies its
// initialization/messaging/clock, but does NOT certify a WebGL browser or Safari.
import { readFile, writeFile } from 'node:fs/promises';
import { createContext, runInContext } from 'node:vm';
import assert from 'node:assert/strict';
const messages=[],results=[];
const context=createContext({console,Blob,Response,performance,setTimeout,clearTimeout,Uint8Array,ArrayBuffer,TextDecoder,TextEncoder,self:{},postMessage:m=>messages.push(structuredClone(m))});
runInContext(await readFile('dist/physics.worker.js','utf8'),context,{filename:'physics.worker.js'});
const send=data=>context.self.onmessage({data});
async function waitFor(predicate,timeout=3000) {
  const start=performance.now();while(!predicate()) {const error=messages.find(m=>m.type==='error');if(error)throw Error(error.error);if(performance.now()-start>timeout)throw Error('Timeout worker');await new Promise(r=>setTimeout(r,10));}
}
const state=()=>messages.filter(m=>m.state).at(-1)?.state;
try {
  await send({type:'init',blob:new Blob([await readFile('dist/mtb-test.vpx')])});
  assert.ok(messages.find(m=>m.type==='ready'));assert.equal(state().flippers.length,4);results.push('VPX load and ready');
  await send({type:'launch'});await send({type:'resume'});await send({type:'frame'});await waitFor(()=>state().time>0);
  const first=state().ball;assert.ok(first);await send({type:'flip',side:'left',down:true});await send({type:'flip',side:'right',down:true});
  for(let n=0;n<20;n++){await new Promise(r=>setTimeout(r,10));await send({type:'frame'});}
  assert.ok(state().ball);assert.notEqual(state().ball.y,first.y);results.push('ball motion');
  assert.ok(Math.abs(state().flippers[0].angle*180/Math.PI-70)<1);assert.ok(Math.abs(state().flippers[1].angle*180/Math.PI-290)<1);results.push('both flippers');
  await send({type:'flip',side:'left',down:false});
  for(let n=0;n<35;n++){await new Promise(r=>setTimeout(r,10));await send({type:'frame'});}
  assert.ok(Math.abs(state().flippers[0].angle*180/Math.PI-121)<1);assert.ok(Math.abs(state().flippers[1].angle*180/Math.PI-290)<1);results.push('independent flipper release');
  await send({type:'pause'});const time=state().time;await new Promise(r=>setTimeout(r,80));await send({type:'frame'});assert.equal(state().time,time);results.push('pause clock');
  await new Promise(r=>setTimeout(r,80));await send({type:'resume'});await new Promise(r=>setTimeout(r,30));await send({type:'frame'});await waitFor(()=>state().time>time);assert.ok(state().time-time<100);results.push('resume without suspension catch-up');
  await send({type:'launch'});assert.ok(state().ball);results.push('relaunch');
  console.log('PASS worker browser bundle in Node VM:',results);
  await writeFile('reports/worker-results.json',JSON.stringify({date:new Date().toISOString(),pass:true,environment:'Node VM, not a browser',checks:results},null,2));
} catch(error) {
  await writeFile('reports/worker-results.json',JSON.stringify({pass:false,checks:results,error:error.stack},null,2));throw error;
} finally {await send({type:'pause'});}
