// SPDX-License-Identifier: GPL-2.0-or-later
import * as esbuild from 'esbuild';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdir, cp, writeFile, rm } from 'node:fs/promises';
import { createRequire } from 'node:module';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
export const vpxPlugin = {
  name: 'vpx-browser-platform',
  setup(build) {
    // Upstream's intended browser platform adapter; physics files stay intact.
    build.onResolve({ filter: /refs\.node$/ }, () => ({ path: resolve(root, 'vendor/vpx-js/lib/refs.browser.ts') }));
    if (build.initialOptions.platform === 'node') return;
    for (const [builtin, pkg] of Object.entries({ events: 'events/', stream: 'stream-browserify', zlib: 'browserify-zlib', process: 'process/browser.js', path: 'path-browserify', util: 'util/', assert: 'assert/' })) {
      build.onResolve({ filter: new RegExp(`^${builtin}$`) }, () => ({ path: require.resolve(pkg) }));
    }
  }
};
export const options = {
  absWorkingDir: root, bundle: true, platform: 'browser', target: ['safari15'],
  inject: [resolve(root, 'src/polyfills.js')], define: { global: 'globalThis' },
  plugins: [vpxPlugin], loader: { '.vbs': 'text', '.bnf': 'text', '.png': 'dataurl', '.jpg': 'dataurl' },
  legalComments: 'external', sourcemap: true, metafile: true,
};
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const pages=process.env.PAGES_BUILD==='1';
  if(pages)await rm(resolve(root,'dist'),{recursive:true,force:true});
  await mkdir(resolve(root, 'dist'), { recursive: true });
  await mkdir(resolve(root, 'reports'), { recursive: true });
  await cp(resolve(root, 'public'), resolve(root, 'dist'), { recursive: true });
  for (const [entry, output] of [['src/main.js', 'app.js'], ['src/physics.worker.js', 'physics.worker.js'], ['src/diagnostics.js', 'diagnostics.js']]) {
    const result = await esbuild.build({ ...options, ...(pages?{minify:true,keepNames:true,sourcemap:false}:{}),entryPoints: [entry], outfile: `dist/${output}`, format: 'iife' });
    await writeFile(resolve(root, `reports/${output}.metafile.json`), JSON.stringify(result.metafile, null, 2));
  }
  if(pages)await writeFile(resolve(root,'dist/.nojekyll'),'');
  console.log('Build Safari terminé : dist/');
}
