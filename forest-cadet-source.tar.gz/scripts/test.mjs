// SPDX-License-Identifier: GPL-2.0-or-later
import { build } from 'esbuild';
import { options } from './build.mjs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { mkdir, writeFile } from 'node:fs/promises';
await mkdir('reports', {recursive:true});
await build({ ...options, entryPoints:['tests/physics.test.js'], outfile:'reports/physics-tests.cjs', format:'cjs', platform:'node', sourcemap:false });
await createRequire(import.meta.url)(resolve('reports/physics-tests.cjs')).run();
