// SPDX-License-Identifier: GPL-2.0-or-later
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
let output=`MTB Pinball 3D Arcade — crédits et licences\n\nCode MTB : GPL-2.0-or-later. Voir LICENSE.txt et les sources de l'archive.\nVPX-JS : freezy / VPDB et contributeurs, GPL-2.0 (en-têtes GPL-2.0-or-later conservés).\nhttps://github.com/vpdb/vpx-js @ e8a6d6fa52262a757d38b2317d845043e5fe1c95\nVPWeb : freezy et contributeurs, GPL-2.0, sources de référence.\nhttps://github.com/freezy/vpweb @ c0b28d383577fa979509d966198d100f2647f5c8\nPhysique : port JavaScript/TypeScript de Visual Pinball 10.6, auteurs Visual Pinball et VPX-JS.\nPlateau MTB : générateur GPL de ce projet ; métadonnées de la fixture GPL table-empty.vpx de VPX-JS.\nAucune ROM ou table commerciale livrée. Les deux grandes tables et leurs captures présentes dans VPWeb ne sont pas redistribuées.\nCFB (Apache-2.0) est un outil de génération indépendant ; il ne fait pas partie du jeu navigateur.\nLes fichiers LEGAL.txt adjacents aux bundles préservent également les notices extraites par esbuild.\n\nDépendances de compilation, tests et bundles — notices disponibles dans l'installation verrouillée :\n`;
const packages=[];
async function walk(path){
 for(const item of await readdir(path,{withFileTypes:true})){
  if(!item.isDirectory()||item.name.startsWith('.'))continue;
  const dir=join(path,item.name);
  if(item.name.startsWith('@')){await walk(dir);continue;}
  try{const pkg=JSON.parse(await readFile(join(dir,'package.json'),'utf8'));packages.push({dir,pkg});}catch{}
  try{await walk(join(dir,'node_modules'));}catch{}
 }
}
await walk('node_modules');
packages.sort((a,b)=>a.pkg.name.localeCompare(b.pkg.name));
for(const {dir,pkg} of packages){
 output+=`\n=== ${pkg.name} ${pkg.version} — ${typeof pkg.license==='string'?pkg.license:JSON.stringify(pkg.license || pkg.licenses || 'voir le paquet')} ===\n`;
 for(const name of await readdir(dir))if(/^(licen[sc]e|notice|copying|copyright)(\.|$|-)/i.test(name)){
  try{output+=`\n${name}\n${await readFile(join(dir,name),'utf8')}\n`;}catch{}
 }
}
await writeFile('public/THIRD_PARTY_NOTICES.txt',output);await writeFile('THIRD_PARTY_NOTICES.txt',output);
console.log(`${packages.length} notices de dépendances réunies.`);
