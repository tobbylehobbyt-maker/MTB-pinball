// SPDX-License-Identifier: GPL-2.0-or-later
// Optional: reproduce the two legacy builds from exact GitHub commits.
import { spawn } from 'node:child_process';
import { mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
async function run(command,args,cwd,env=process.env){await new Promise((ok,fail)=>{const p=spawn(command,args,{cwd,env,stdio:'inherit'});p.on('error',fail);p.on('exit',code=>code===0?ok():fail(Error(`${command} ${args.join(' ')} : ${code}`)));});}
const base=resolve('upstream-rebuild');await mkdir(base,{recursive:true});
for(const [name,url,commit]of [
 ['vpx-js','https://github.com/vpdb/vpx-js.git','e8a6d6fa52262a757d38b2317d845043e5fe1c95'],
 ['vpweb','https://github.com/freezy/vpweb.git','c0b28d383577fa979509d966198d100f2647f5c8'],
]){
 // A fresh folder makes this command non-destructive and its checkout explicit.
 await run('git',['clone',url,name],base);await run('git',['checkout','--detach',commit],resolve(base,name));
}
const npm=process.platform==='win32'?'npm.cmd':'npm';
const vpx=resolve(base,'vpx-js'),web=resolve(base,'vpweb');
await run(npm,['ci','--ignore-scripts'],vpx);await run(npm,['run','build'],vpx);
await run(npm,['ci','--ignore-scripts'],web);
await run(npm,['install','--ignore-scripts','--save-exact','../vpx-js','sass@1.32.13'],web);
await run(npm,['uninstall','node-sass','--ignore-scripts'],web);
await run(npm,['run','build'],web,{...process.env,NODE_OPTIONS:[process.env.NODE_OPTIONS,'--openssl-legacy-provider'].filter(Boolean).join(' ')});
console.log('Deux compilations originales terminées dans upstream-rebuild/.');
