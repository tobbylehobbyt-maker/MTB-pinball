// SPDX-License-Identifier: GPL-2.0-or-later
import { chromium, webkit } from 'playwright';
import assert from 'node:assert/strict';
import { writeFile, mkdir } from 'node:fs/promises';
import { serve } from './serve.mjs';
const server=serve(0); await new Promise(resolve=>server.once('listening',resolve));
const url=`http://127.0.0.1:${server.address().port}`;
await mkdir('reports',{recursive:true});
const results=[];
for(const [name, browserType] of [['chromium',chromium],['webkit',webkit]]) {
  let browser;
  try {
    const executablePath=process.env[name==='chromium'?'CHROMIUM_EXECUTABLE':'WEBKIT_EXECUTABLE'];
    const args = name==='chromium' ? (process.env.CHROMIUM_ARGS ? JSON.parse(process.env.CHROMIUM_ARGS) : ['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader']) : [];
    browser=await browserType.launch({headless:true,executablePath:executablePath || undefined,args,env:{...process.env,TMPDIR:process.env.TMPDIR || process.cwd()+'/reports'}});
    const page=await browser.newPage({viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(url); await page.waitForFunction(()=>window.MTB?.ready,{},{timeout:20000});
    const initial=await page.evaluate(()=>MTB.state);
    assert.equal(initial.flippers.length,2);assert.equal(initial.ball,null);
    await page.locator('#launch').click();await page.waitForFunction(()=>MTB.state.ball);
    const first=await page.evaluate(()=>MTB.state.ball);
    await page.waitForTimeout(160);const second=await page.evaluate(()=>MTB.state.ball);
    assert.ok(second);assert.notEqual(first.y,second.y);
    // DOM multi-pointer integration in both engines. Synthetic events do not
    // validate iOS hardware touch delivery.
    await page.evaluate(()=> {
      const l=document.getElementById('left'),r=document.getElementById('right');
      l.setPointerCapture=()=>{};r.setPointerCapture=()=>{};
      l.dispatchEvent(new PointerEvent('pointerdown',{pointerId:21,pointerType:'touch',bubbles:true,cancelable:true}));
      r.dispatchEvent(new PointerEvent('pointerdown',{pointerId:22,pointerType:'touch',bubbles:true,cancelable:true}));
    });
    await page.waitForFunction(()=>Math.abs(MTB.state.flippers[0].angle*180/Math.PI-70)<1&&Math.abs(MTB.state.flippers[1].angle*180/Math.PI-290)<1);
    await page.evaluate(()=>document.getElementById('left').dispatchEvent(new PointerEvent('pointercancel',{pointerId:21,pointerType:'touch',bubbles:true})));
    await page.waitForFunction(()=>Math.abs(MTB.state.flippers[0].angle*180/Math.PI-121)<1&&Math.abs(MTB.state.flippers[1].angle*180/Math.PI-290)<1);
    await page.evaluate(()=>document.getElementById('right').dispatchEvent(new PointerEvent('pointerup',{pointerId:22,pointerType:'touch',bubbles:true})));
    await page.waitForFunction(()=>Math.abs(MTB.state.flippers[1].angle*180/Math.PI-239)<1);
    await page.locator('#pause').click();await page.waitForTimeout(100);
    const paused=await page.evaluate(()=>MTB.state.time);await page.waitForTimeout(250);
    assert.equal(await page.evaluate(()=>MTB.state.time),paused);
    await page.screenshot({path:`reports/${name}-portrait.png`});
    await page.setViewportSize({width:844,height:390});await page.waitForTimeout(100);
    assert.ok(await page.locator('#left').isVisible());await page.screenshot({path:`reports/${name}-landscape.png`});
    assert.deepEqual(errors,[]);assert.deepEqual(await page.evaluate(()=>MTB.errors),[]);
    results.push({name,pass:true,version:browser.version(),checks:['worker boot','VPX parse','3D WebGL','ball motion','both flippers','independent release','pointercancel','pause freezes time','portrait and landscape','no page errors'],fps:await page.evaluate(()=>MTB.fps)});
  } catch(error) { results.push({name,pass:false,error:error.stack});console.error(name,error.message); }
  finally { await browser?.close(); }
}
server.close();
await writeFile('reports/browser-results.json',JSON.stringify({date:new Date().toISOString(),results},null,2));
console.log(JSON.stringify(results,null,2));if(results.some(r=>!r.pass))process.exitCode=1;
