// SPDX-License-Identifier: GPL-2.0-or-later
import { serve } from './serve.mjs';
import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
const server=serve(0);await new Promise(resolve=>server.once('listening',resolve));
const base=`http://127.0.0.1:${server.address().port}`;
try{
 const checks=[];
 for(const [file,mime]of [['/','text/html'],['/app.js','text/javascript'],['/physics.worker.js','text/javascript'],['/diagnostics.js','text/javascript'],['/diagnostics.html','text/html'],['/style.css','text/css'],['/mtb-test.vpx','application/octet-stream'],['/LICENSE.txt','text/plain'],['/THIRD_PARTY_NOTICES.txt','text/plain']]){
  const r=await fetch(base+file);assert.equal(r.status,200,file);assert.ok(r.headers.get('content-type').startsWith(mime),file);assert.ok((await r.arrayBuffer()).byteLength>0);checks.push(file);
 }
 const missing=await fetch(base+'/missing');assert.equal(missing.status,404);
 const traversal=await fetch(base+'/..%2f..%2fpackage.json');assert.equal(traversal.status,403);
 await writeFile('reports/server-results.json',JSON.stringify({date:new Date().toISOString(),pass:true,checks,missing:404,traversal:403},null,2));console.log('PASS HTTP distribution',checks);
}finally{server.close();}
