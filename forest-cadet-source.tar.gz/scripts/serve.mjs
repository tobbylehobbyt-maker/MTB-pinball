// SPDX-License-Identifier: GPL-2.0-or-later
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, dirname, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { networkInterfaces } from 'node:os';
export function serve(port = 8080) {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '../dist');
  const mime = { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.vpx':'application/octet-stream','.txt':'text/plain; charset=utf-8' };
  const server = createServer(async (request, response) => {
    try {
      const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
      const path = resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
      if (!path.startsWith(root + sep)) { response.writeHead(403); response.end(); return; }
      if (!(await stat(path)).isFile()) throw new Error('Not found');
      response.writeHead(200, { 'Content-Type':mime[extname(path)] || 'application/octet-stream', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
      response.end(await readFile(path));
    } catch { response.writeHead(404); response.end('Fichier introuvable'); }
  });
  server.listen(port, '0.0.0.0', () => {
    const actual = server.address().port;
    console.log(`Mac : http://localhost:${actual}`);
    let interfaces = {}; try { interfaces = networkInterfaces(); } catch { console.log('iPhone : utilisez l’adresse Wi-Fi du Mac avec ce port.'); }
    for (const list of Object.values(interfaces)) for (const item of list || []) {
      if (item.family === 'IPv4' && !item.internal) console.log(`iPhone (même Wi-Fi) : http://${item.address}:${actual}`);
    }
  });
  return server;
}
if (process.argv[1] === fileURLToPath(import.meta.url)) serve(Number(process.env.PORT || 8080));
