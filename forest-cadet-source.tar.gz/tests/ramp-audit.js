import {createEngine} from '../src/engine.js';
import {readFileSync} from 'node:fs';
const blob=new Blob([readFileSync('public/mtb-test.vpx')]);
(async()=>{
for(const name of ['LeftRamp','RightRamp'])for(const speed of [8,30,35,40]){
 const e=await createEngine(blob),r=e.snapshot().ramps.find(r=>r.name===name);
 const center=i=>({x:(r.left[i].x+r.right[i].x)/2,y:(r.left[i].y+r.right[i].y)/2,z:r.left[i].z});
 const a=center(0),q=center(2),len=Math.hypot(q.x-a.x,q.y-a.y);
 const b=e.spawn(a.x-(q.x-a.x)/len*35,a.y-(q.y-a.y)/len*35,(q.x-a.x)/len*speed,(q.y-a.y)/len*speed);
 let maxZ=0,minY=1100,maxIndex=0,returned=false;
 for(let t=0;t<=5000;t+=5){e.player.updatePhysics(t);e.updateRules();const p=b.getState().pos;maxZ=Math.max(maxZ,p.z);minY=Math.min(minY,p.y);if(t>100&&p.y>a.y+35)returned=true;let d=1e9;for(let i=0;i<r.left.length;i++){const c=center(i),dist=Math.hypot(p.x-c.x,p.y-c.y,p.z-c.z-25);if(dist<d){d=dist;if(d<35)maxIndex=Math.max(maxIndex,i);}}}
 console.log(name,speed,{maxZ,minY,maxIndex,returned,passes:e.snapshot().rampPasses,final:e.snapshot().ball});
}

})();
