// SPDX-License-Identifier: GPL-2.0-or-later
import assert from 'node:assert/strict';
import process from 'node:process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createEngine,centerReturnVelocity } from '../src/engine.js';
import { createArcade } from '../src/arcade.js';
import { InputState } from '../src/input.js';
const bytes = readFileSync('public/mtb-test.vpx');
const fresh = () => createEngine(new Blob([bytes]));
const results = [];
async function test(name, run) {
  try { const detail = await run(); results.push({name,pass:true,detail}); console.log(`PASS ${name}`,detail || ''); }
  catch(error) { results.push({name,pass:false,error:error.stack}); console.error(`FAIL ${name}`,error); }
}
function advance(e, end, begin=0) { for(let t=begin;t<=end;t+=5) { e.player.updatePhysics(t); e.player.updateAnimations(e.player.getGameTime()); } }
export async function run() {
await test('Combo : alternance, jackpot, expiration et skill shot unique',()=>{
 const a=createArcade();a.beginBall(0);a.hit('Target0',100);assert.equal(a.snapshot().score,2800);a.hit('Target0',200);assert.equal(a.snapshot().score,3100);
 a.ramp('LeftRamp',1000);a.ramp('RightRamp',2000);a.ramp('LeftRamp',3000);assert.equal(a.snapshot().combo,3);assert.equal(a.snapshot().jackpots,1);assert.equal(a.snapshot().score,22100);
 a.ramp('LeftRamp',4000);assert.equal(a.snapshot().combo,1);a.ramp('RightRamp',22000);assert.equal(a.snapshot().combo,1);a.reset();assert.equal(a.snapshot().score,0);assert.equal(a.snapshot().jackpots,0);
});
await test('Six missions : progression par tirs réels puis cycle suivant',()=>{const a=createArcade();for(let i=0;i<5;i++)a.hit('Rock4');for(let i=0;i<3;i++)a.hit('Boost');for(let i=0;i<8;i++)a.hit('Bumper7');assert.equal(a.snapshot().mission,'Ascension du sommet');a.ramp('LeftRamp',1000);a.ramp('RightRamp',2000);assert.equal(a.snapshot().mission,'Balisage alpin');for(let i=0;i<3;i++)a.hit(`Target${i}`,3000);assert.equal(a.snapshot().mission,'Descente nocturne');for(let i=0;i<5;i++)a.hit('Boost',4000);assert.equal(a.snapshot().mission,'Rock garden');assert.equal(a.snapshot().rank,7);});
await test('Partie de trois billes, sauvegarde et remise à zéro',async()=>{
 const e=await fresh();for(let i=1;i<=3;i++){e.stage();e.fire();assert.equal(e.snapshot().ballNumber,i);assert.equal(e.drain(),false);assert.equal(e.snapshot().ballNumber,i);assert.equal(e.drain(),true);}assert.ok(e.snapshot().gameOver);assert.equal(e.player.balls.length,0);e.newGame();assert.equal(e.snapshot().ballNumber,1);assert.equal(e.snapshot().score,0);assert.ok(e.snapshot().staged);assert.ok(!e.snapshot().gameOver);
});
await test('Secousse : impulsion et tilt sans sauvegarde',async()=>{
 const e=await fresh();e.stage();e.fire();e.nudge();advance(e,600);e.nudge();advance(e,1200,605);e.nudge();assert.ok(e.snapshot().tilted);assert.equal(e.drain(),true);assert.equal(e.player.balls.length,0);e.stage();e.fire();assert.ok(!e.snapshot().tilted);
});
await test('Bille coincée : deux dégagements puis relance sans consommer de bille',async()=>{const e=await fresh(),b=e.spawn(300,600,0,0);for(let t=0;t<=13000;t+=100){e.player.updatePhysics(t);b.getState().pos.set(300,600,25);b.hit.vel.set(0,0,0);e.updateRules();if(e.snapshot().ballRecoveries)break;}assert.equal(e.snapshot().ballRecoveries,1);assert.equal(e.snapshot().ballNumber,1);assert.equal(e.player.balls.length,1);assert.equal(b.getState().pos.x,575);assert.ok(b.hit.vel.y<0);});
await test('Blocage sur surface plate : oscillations détectées et dégagement vertical',async()=>{const e=await fresh(),b=e.spawn(170,780,0,0);let lifted=false;for(let t=0;t<=13000;t+=100){e.player.updatePhysics(t);b.getState().pos.set(170+Math.sin(t/200)*14,780,105);b.hit.vel.set(2,0,0);e.updateRules();if(b.hit.vel.z>=2.5)lifted=true;if(e.snapshot().ballRecoveries)break;}assert.ok(lifted);assert.equal(e.snapshot().ballRecoveries,1);assert.equal(e.snapshot().ballNumber,1);});
await test('Protection anti-blocage : lanceur en attente et bille mobile ignorés',async()=>{const e=await fresh();e.stage();for(let t=0;t<=15000;t+=100){e.player.updatePhysics(t);e.updateRules();}assert.equal(e.snapshot().ballRecoveries,0);assert.ok(e.snapshot().staged);const b=e.spawn(300,600,0,0);for(let t=15100;t<=28000;t+=100){e.player.updatePhysics(t);b.getState().pos.set(200+(t%2000)/10,600,25);b.hit.vel.set(2,0,0);e.updateRules();}assert.equal(e.snapshot().ballRecoveries,0);});
await test('Batteurs supérieurs : synchronisation gauche/droite et relâchement',async()=>{const e=await fresh();e.flip('left',true);e.flip('right',true);advance(e,200);for(const f of e.snapshot().flippers){const degrees=f.angle*180/Math.PI;assert.ok(Math.abs(degrees-(f.name.includes('Left')?70:290))<1);}e.flip('left',false);advance(e,400,205);const upper=e.snapshot().flippers.find(f=>f.name==='UpperLeftFlipper');assert.ok(Math.abs(upper.angle*180/Math.PI-121)<1);});
await test('Kickback gauche : deux sauvetages physiques, puis gouttière normale',async()=>{const e=await fresh();const b=e.spawn(38,900,0,8);e.updateRules();assert.ok(b.hit.vel.y<-28);assert.ok(b.hit.vel.x>0);assert.equal(b.getState().pos.y,900);assert.equal(e.snapshot().kickbacks,1);advance(e,2000);b.getState().pos.set(38,900,25);b.hit.vel.set(0,8,0);e.updateRules();assert.equal(e.snapshot().kickbacks,0);advance(e,4000,2005);b.getState().pos.set(38,900,25);b.hit.vel.set(0,8,0);e.updateRules();assert.equal(b.hit.vel.y,8);e.setMode('classic');const c=e.spawn(38,900,0,8);e.updateRules();assert.equal(c.hit.vel.y,8);});
await test('Boost gauche : retour central modéré avec variation bornée',async()=>{const e=await fresh();const b=e.spawn(140,490,-10,0);e.updateRules();assert.ok(b.hit.vel.x>0&&b.hit.vel.x<=8);assert.equal(b.hit.vel.y,-24);});
await test('Rebond gauche Arcade : impulsion droite après collision, sans téléportation',async()=>{const e=await fresh();const b=e.spawn(215,155,10,0);advance(e,100);assert.ok(b.hit.vel.x<0);const p={x:b.getState().pos.x,y:b.getState().pos.y};e.updateRules();assert.ok(b.hit.vel.x>0&&b.hit.vel.x<=8);assert.equal(b.getState().pos.x,p.x);assert.equal(b.getState().pos.y,p.y);e.setMode('classic');const c=e.spawn(215,155,10,0);advance(e,200,105);e.updateRules();assert.ok(c.hit.vel.x<0);});
await test('Turbo tube : aspiration, accélération, boucle complète et sortie sans perte',async()=>{const e=await fresh();const r=e.snapshot().ramps[0],x=(r.left[0].x+r.right[0].x)/2,y=(r.left[0].y+r.right[0].y)/2;const b=e.spawn(x,y,0,0);advance(e,205);b.getState().pos.set(x,y,29);e.updateRules();assert.ok(e.snapshot().tubeRide);let maxSpeed=0,maxZ=0;for(let t=210;t<=6000;t+=5){e.player.updatePhysics(t);e.updateRules();maxZ=Math.max(maxZ,b.getState().pos.z);maxSpeed=Math.max(maxSpeed,e.snapshot().tubeRide?.speed||0);if(e.snapshot().rampPasses)break;}assert.ok(maxSpeed>1);assert.ok(maxZ>200);assert.equal(e.snapshot().rampPasses,1);assert.equal(e.snapshot().tubeRide,null);assert.ok(b.hit.vel.x>0&&b.hit.vel.x<=8);assert.equal(e.snapshot().ballNumber,1);});
await test('Retours centrés : symétrie gauche/droite, dispersion faible et vitesse limitée',()=>{assert.equal(centerReturnVelocity(100,()=>.5),-centerReturnVelocity(500,()=>.5));assert.equal(centerReturnVelocity(300,()=>.5),0);for(const x of [0,100,300,500,600])for(const r of [0,.5,1])assert.ok(Math.abs(centerReturnVelocity(x,()=>r))<=8);});
await test('Matériaux Visual Pinball : bois, métal, caoutchouc et dispersion modérée',async()=>{const e=await fresh();assert.equal(e.table.data.globalDifficulty,.15);assert.equal(e.table.data.elasticity,.25);for(const [name,value] of [['LeftWoodGuide',.4],['Target0',.375],['LeftGuide',.8],['LaunchLane',.3]]){for(const h of e.table.surfaces[name].getHitShapes()){assert.equal(h.elasticity,value);assert.ok(Math.abs(h.scatter-5*Math.PI/180)<1e-8);}}});
await test('Bille : rayon physique réduit de moitié',async()=>{const e=await fresh();e.spawn(300,600,0,0);assert.equal(e.snapshot().ballRadius,12.5);advance(e,300);assert.ok(Math.abs(e.snapshot().ball.z-12.5)<1);});
await test('Capteurs de rampe : petite bille, parcours complet et score unique',async()=>{const e=await fresh();e.setMode('classic');const r=e.snapshot().ramps[0],b=e.spawn(220,700,0,0);for(let i=0;i<r.left.length;i++){e.player.updatePhysics(i*10);const a=r.left[i],c=r.right[i];b.getState().pos.set((a.x+c.x)/2,(a.y+c.y)/2,a.z+12.5);b.hit.vel.set(0,0,0);e.updateRules();}assert.equal(e.snapshot().rampPasses,1);e.updateRules();assert.equal(e.snapshot().rampPasses,1);});
await test('VPX réellement parsé : 4 batteurs, guides en bois et 3 rochers',async () => {
  const e=await fresh(); assert.equal(Object.keys(e.table.flippers).length,4); assert.equal(Object.keys(e.table.surfaces).length,14);
  assert.equal(e.table.data.right,600); assert.equal(e.table.data.bottom,1100);
  return e.snapshot();
});
await test('Cibles escamotables : impact unique, banque complète et réarmement',async()=>{const e=await fresh();const hit=i=>e.table.surfaces[`Target${i}`].getApi().emit('Hit');hit(0);const score=e.snapshot().score;hit(0);assert.equal(e.snapshot().score,score);hit(1);hit(2);assert.equal(e.snapshot().targetDropped.length,3);assert.equal(e.snapshot().multiplier,2);advance(e,1500);e.updateRules();assert.equal(e.snapshot().targetDropped.length,0);hit(0);assert.ok(e.snapshot().score>score);});
await test('Mode classique : boost sans propulsion, nouvelle partie et nudge latéral',async()=>{const e=await fresh();e.setMode('classic');const b=e.spawn(140,490,0,0);e.updateRules();assert.equal(b.hit.vel.y,0);assert.equal(e.snapshot().boosts,1);assert.equal(e.snapshot().mode,'classic');e.nudge('left');assert.ok(b.hit.vel.x<0);e.setMode('arcade');assert.equal(e.snapshot().score,0);assert.ok(e.snapshot().staged);});
await test('Boost MTB : impulsion, score et cooldown',async () => { const e=await fresh(); const b=e.spawn(140,490,0,0); e.updateRules(); assert.equal(b.hit.vel.y,-24); assert.equal(e.snapshot().score,250); e.updateRules(); assert.equal(e.snapshot().boosts,1); });
await test('Arcade : cibles distinctes, multiplicateur et trois missions',()=>{const a=createArcade();a.hit('Target0');a.hit('Target0');assert.equal(a.snapshot().multiplier,1);a.hit('Target1');a.hit('Target2');assert.equal(a.snapshot().multiplier,2);for(let i=0;i<5;i++)a.hit('Rock4');assert.equal(a.snapshot().mission,'Flow trail');for(let i=0;i<3;i++)a.hit('Boost');assert.equal(a.snapshot().mission,'Clairière');for(let i=0;i<8;i++)a.hit('Bumper7');assert.equal(a.snapshot().rank,4);});
await test('Protection de bille : un seul sauvetage',async()=>{const e=await fresh();e.spawn();assert.equal(e.drain(),false);assert.equal(e.player.balls.length,1);assert.equal(e.drain(),true);assert.equal(e.player.balls.length,0);});
await test('Bumper VPX : propulsion réelle',async()=>{const e=await fresh();const b=e.spawn(215,155,10,0);advance(e,100);assert.ok(b.hit.vel.x<0);assert.ok(e.snapshot().score>=200);});
await test('Lanceur : bille visible en attente puis trajet continu',async()=>{const e=await fresh();e.stage();assert.equal(e.snapshot().ball.x,575);assert.ok(e.snapshot().staged);e.fire(1);assert.ok(!e.snapshot().staged);const b=e.player.balls[0];let minY=985;for(let t=0;t<=700;t+=5){e.player.updatePhysics(t);minY=Math.min(minY,b.getState().pos.y);}assert.ok(minY<200);assert.ok(Number.isFinite(b.getState().pos.x));});
await test('Rampes VPX : montée du tir fort, recul du tir faible et absence de double bonus',async()=>{
  const results=[];
  for(const name of ['LeftRamp','RightRamp'])for(const speed of [8,name==='LeftRamp'?27.5:25]){
    const e=await fresh();e.setMode('classic');const r=e.snapshot().ramps.find(r=>r.name===name);
    const center=i=>({x:(r.left[i].x+r.right[i].x)/2,y:(r.left[i].y+r.right[i].y)/2,z:r.left[i].z});
    const a=center(0),q=center(2),d=Math.hypot(q.x-a.x,q.y-a.y),dx=(q.x-a.x)/d,dy=(q.y-a.y)/d;
    const b=e.spawn(a.x-dx*35,a.y-dy*35,dx*speed,dy*speed);
    let maxZ=0,back=false;
    for(let t=0;t<=5000;t+=5){e.player.updatePhysics(t);e.updateRules();const p=b.getState().pos;assert.ok([p.x,p.y,p.z].every(Number.isFinite));maxZ=Math.max(maxZ,p.z);if(t>300&&p.y>a.y+50)back=true;}
    if(speed>8){assert.ok(e.snapshot().rampPasses<=1);assert.ok(maxZ>200);}else{assert.equal(e.snapshot().rampPasses,0);assert.ok(back);}
    results.push({name,speed,maxZ,passes:e.snapshot().rampPasses});
  }return results;
});
await test('Passage sous une rampe élevée sans collision fantôme',async()=>{
  const e=await fresh(),r=e.snapshot().ramps[0],i=75;
  const x=(r.left[i].x+r.right[i].x)/2,y=(r.left[i].y+r.right[i].y)/2;
  assert.ok(r.left[i].z>150);const b=e.spawn(x,y,0,0);advance(e,100);assert.ok(b.getState().pos.z<30);assert.equal(e.snapshot().rampPasses,0);
});
await test('Gouttières distinctes : drainage latéral et retour intérieur',async()=>{
  for(const [x,drain] of [[40,true],[515,true],[115,false],[442,false]]){const e=await fresh();const b=e.spawn(x,990,0,0);assert.equal(e.isDraining(),drain);assert.ok(b.getState().pos.y===990);}
});
await test('Slingshot droit : impulsion mécanique vers le centre',async()=>{const e=await fresh();const b=e.spawn(330,810,10,0);advance(e,100);assert.ok(b.hit.vel.x<0);assert.ok(e.snapshot().collisions>0);});
await test('Une bille seulement après plusieurs lancements',async () => { const e=await fresh(); e.spawn();e.spawn();e.spawn();assert.equal(e.player.balls.length,1); });
await test('Gravité VPX, plan du plateau et coordonnées finies',async () => {
  const e=await fresh();const b=e.spawn(300,300,0,0);advance(e,500);
  const p=b.getState().pos;assert.ok(p.y>300); assert.ok(Math.abs(p.z-12.5)<1); assert.ok([p.x,p.y,p.z].every(Number.isFinite));
  return {x:p.x,y:p.y,z:p.z};
});
await test('Collision réelle du bord droit : inversion vitesse X',async () => {
  const e=await fresh();const b=e.spawn(500,550,12,0);advance(e,100);
  assert.ok(b.hit.vel.x<0);assert.ok(b.getState().pos.x<537);
  return {x:b.getState().pos.x,vx:b.hit.vel.x};
});
await test('Deux batteurs simultanés : montée et retour physiques',async () => {
  const e=await fresh(); e.flip('left',true);e.flip('right',true);advance(e,100);
  const left=e.table.flippers.LeftFlipper.getState().angle*180/Math.PI,right=e.table.flippers.RightFlipper.getState().angle*180/Math.PI;
  assert.ok(Math.abs(left-70)<1);assert.ok(Math.abs(right-290)<1);
  e.flip('left',false);e.flip('right',false);advance(e,800,105);
  assert.ok(Math.abs(e.table.flippers.LeftFlipper.getState().angle*180/Math.PI-121)<1);
  assert.ok(Math.abs(e.table.flippers.RightFlipper.getState().angle*180/Math.PI-239)<1);
  return {left,right};
});
await test('Guide gauche : déviation réelle de la bille',async () => {
  const e=await fresh();const b=e.spawn(235,810,-10,0);advance(e,100);
  assert.ok(b.hit.vel.x>0);assert.ok(e.snapshot().collisions>0);assert.ok(b.getState().pos.x>100);
  return {x:b.getState().pos.x,y:b.getState().pos.y,vx:b.hit.vel.x};
});
await test('Batteur gauche : transfert de force vers la bille',async () => {
  const e=await fresh(); const b=e.spawn(185,910,0,0);advance(e,20);e.flip('left',true);let minVy=0,minY=910;for(let t=25;t<=150;t+=5){e.player.updatePhysics(t);minVy=Math.min(minVy,b.hit.vel.y);minY=Math.min(minY,b.getState().pos.y);}
  assert.ok(minVy<-10);assert.ok(minY<900);
  return {y:b.getState().pos.y,vy:b.hit.vel.y,contacts:e.snapshot().collisions};
});
await test('Batteur droit : transfert de force vers la bille',async () => {
  const e=await fresh(); const b=e.spawn(415,910,0,0);advance(e,20);e.flip('right',true);let minVy=0,minY=910;for(let t=25;t<=150;t+=5){e.player.updatePhysics(t);minVy=Math.min(minVy,b.hit.vel.y);minY=Math.min(minY,b.getState().pos.y);}
  assert.ok(minVy<-10);assert.ok(minY<900);
  return {y:b.getState().pos.y,vy:b.hit.vel.y,contacts:e.snapshot().collisions};
});
await test('Multitouch : indépendance, deux doigts sur un côté, clavier et annulation',() => {
  const sent=[];const s=new InputState((side,down)=>sent.push([side,down]));
  s.press('p1','left');s.press('p2','right');s.press('p3','left');s.release('p1'); assert.ok(s.down('left'));
  s.release('p2');assert.ok(!s.down('right'));s.press('kA','left');s.release('p3');assert.ok(s.down('left'));
  s.clear();assert.ok(!s.down('left'));assert.deepEqual(sent,[['left',true],['right',true],['right',false],['left',false]]);
});
await test('Simulation de 30 secondes : aucune coordonnée non finie',async () => {
  const e=await fresh(); e.spawn(); let maxZ=0;
  for(let t=0;t<=30000;t+=5) { if(t%700===0)e.flip('left',true);if(t%700===100)e.flip('left',false);if(t%900===0)e.flip('right',true);if(t%900===100)e.flip('right',false);e.player.updatePhysics(t);
    const p=e.player.balls[0].getState().pos;assert.ok([p.x,p.y,p.z].every(Number.isFinite)); maxZ=Math.max(maxZ,p.z);
  }
  return {maxZ,contacts:e.snapshot().collisions};
});
writeFileSync('reports/physics-results.json',JSON.stringify({date:new Date().toISOString(),node:process.version,results},null,2));
if(results.some(r=>!r.pass))process.exitCode=1;
}
